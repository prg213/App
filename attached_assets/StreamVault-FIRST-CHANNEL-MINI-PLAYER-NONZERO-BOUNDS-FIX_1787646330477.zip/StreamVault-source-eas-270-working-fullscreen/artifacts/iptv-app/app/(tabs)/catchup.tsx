import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { FocusablePressable } from '@/components/FocusablePressable';
import { useBackHandler } from '@/hooks/useBackHandler';
import {
  ActivityIndicator,
  findNodeHandle,
  FlatList,
  Image,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  View,
  type NativeScrollEvent,
  type NativeSyntheticEvent,
} from 'react-native';
import { useFocusEffect } from 'expo-router';
import { useQuery } from '@tanstack/react-query';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useAppContext } from '@/context/AppContext';
import {
  getXtreamLiveCategories,
  getXtreamLiveStreams,
  getXtreamCatchupEpg,
  getXtreamCatchupUrls,
} from '@/services/xtreamApi';
import type { CatchupProgram, Category, Channel } from '@/types';
import { sidebarNav } from '@/lib/sidebarNav';
import { requestTvFocus } from '@/lib/tvFocus';

function buildCreds(c: ReturnType<typeof useAppContext>['credentials']) {
  return { host: c?.host ?? '', username: c?.username ?? '', password: c?.password ?? '' };
}

function fmtTime(d: Date) {
  let h = d.getHours();
  const m = d.getMinutes();
  const ampm = h >= 12 ? 'pm' : 'am';
  h = h % 12 || 12;
  return `${h}:${String(m).padStart(2, '0')}${ampm}`;
}

function dayKey(d: Date) {
  return `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}`;
}

function dayLabel(d: Date) {
  const today = new Date();
  const yesterday = new Date(today.getTime() - 86400_000);
  if (dayKey(d) === dayKey(today)) return 'Today';
  if (dayKey(d) === dayKey(yesterday)) return 'Yesterday';
  return d.toLocaleDateString(undefined, { weekday: 'short', day: 'numeric', month: 'short' });
}

function initialsOf(name: string) {
  return name.split(/\s+/).slice(0, 2).map((w) => w[0]?.toUpperCase() ?? '').join('');
}

const ALL_CAT_ID = '__all__';
// Categories and channels are visually paired grids.  Keep their rows
// identical so a long category name or an archive subtitle cannot accumulate
// vertical drift between the two independently virtualised lists.
const CATCHUP_GRID_ROW_H = 58;

// ─── Category Row ─────────────────────────────────────────────────────────────

const CategoryRow = React.memo(React.forwardRef<View, {
  cat: Category;
  isSelected: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
  nextFocusLeft?: number | null;
}>(function CategoryRow({ cat, isSelected, colors, onPress, nextFocusLeft }, ref) {
  return (
    <FocusablePressable
      ref={ref}
      style={[
        styles.catRow,
        isSelected ? { backgroundColor: '#3B82F6' } : { borderBottomColor: colors.border },
      ]}
      nextFocusLeft={nextFocusLeft}
      onPress={onPress}
    >
      <Text
        style={[styles.catRowText, { color: isSelected ? '#fff' : colors.foreground }]}
        numberOfLines={1}
      >
        {cat.name}
      </Text>
    </FocusablePressable>
  );
}));

// ─── Channel Row ──────────────────────────────────────────────────────────────

const ChannelRow = React.memo(React.forwardRef<View, {
  ch: Channel;
  isSelected: boolean;
  colors: ReturnType<typeof useColors>;
  onPress: () => void;
}>(function ChannelRow({ ch, isSelected, colors, onPress }, ref) {
  return (
    <FocusablePressable
      ref={ref}
      style={[
        styles.chRow,
        { borderBottomColor: colors.border },
        isSelected && { backgroundColor: '#2563EB' },
      ]}
      onPress={onPress}
    >
      <View style={[styles.chLogo, { backgroundColor: colors.muted }]}>
        {ch.logo ? (
          <Image source={{ uri: ch.logo }} style={{ width: 34, height: 24 }} resizeMode="contain" />
        ) : (
          <Text style={[styles.chInitials, { color: colors.mutedForeground }]}>{initialsOf(ch.name)}</Text>
        )}
      </View>
      <View style={{ flex: 1, minWidth: 0 }}>
        <Text
          style={[styles.chName, { color: isSelected ? '#fff' : colors.foreground }]}
          numberOfLines={1}
        >
          {ch.name}
        </Text>
        {(ch.tvArchiveDuration ?? 0) > 0 && (
          <Text style={[styles.chSub, { color: isSelected ? '#93C5FD' : colors.mutedForeground }]}>
            {ch.tvArchiveDuration}d archive
          </Text>
        )}
      </View>
    </FocusablePressable>
  );
}));

// ─── Main Screen ──────────────────────────────────────────────────────────────

export default function CatchupScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { credentials } = useAppContext();

  const isXtream = credentials?.type === 'xtream';
  const creds = isXtream ? buildCreds(credentials) : null;

  const [selectedCatId, setSelectedCatId] = useState<string>(ALL_CAT_ID);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  // Refs for auto-advancing D-pad focus between columns
  const firstCatRef     = useRef<View>(null);
  const firstChannelRef = useRef<View>(null);
  const firstProgRef    = useRef<View>(null);
  const categoryListRef = useRef<FlatList<Category>>(null);
  const channelListRef  = useRef<FlatList<Channel>>(null);
  // Keep the category grid visually paired with the channel grid while the
  // user scrolls through channels. Both lists use the same row height, and
  // this keeps their content offsets identical as well.
  const lastSyncedCategoryOffsetRef = useRef<number | null>(null);
  // Set to true when a channel is selected so the useEffect below fires focus
  // once the programme list data arrives (EPG is fetched asynchronously).
  const pendingProgFocusRef = useRef(false);

  // Stores the native node handle of the first programme row so day tabs can
  // wire nextFocusDown reliably (findNodeHandle at render-time is too early —
  // the node may not be mounted yet when the tabs re-render after a day change).
  const [firstProgHandle, setFirstProgHandle] = useState<number | null>(null);

  // Node handles for each day tab, keyed by day string.  Populated by the
  // stable callback refs below once each tab mounts so adjacent tabs can wire
  // nextFocusLeft / nextFocusRight without relying on render-time handles.
  const [dayTabHandles, setDayTabHandles] = useState<Map<string, number>>(new Map());

  // Hardware BACK: close programme list → reset category → sidebar fallback.
  useBackHandler(() => {
    if (selectedChannel) { setSelectedChannel(null); return true; }
    if (selectedCatId !== ALL_CAT_ID) { setSelectedCatId(ALL_CAT_ID); return true; }
    if (Platform.isTV) { sidebarNav.focus(); return true; }
    return false;
  });

  // Refs that shadow selected-column state so the tab-return useFocusEffect
  // below can read the current values without adding them to its dep array.
  // Adding them as deps would cause the effect to re-fire and steal focus every
  // time the user navigates between columns while the tab is active.
  const selectedChannelForFocusRef = useRef<typeof selectedChannel>(null);
  useEffect(() => { selectedChannelForFocusRef.current = selectedChannel; }, [selectedChannel]);
  const selectedCatIdForFocusRef = useRef<string>(ALL_CAT_ID);
  useEffect(() => { selectedCatIdForFocusRef.current = selectedCatId; }, [selectedCatId]);

  // TV: focus the most contextually relevant element on every tab visit.
  // [] deps — fires on tab-entry only; reads state via refs to avoid stale closures.
  useFocusEffect(useCallback(() => {
    if (!Platform.isTV) return;
    const t = setTimeout(() => {
      const ch  = selectedChannelForFocusRef.current;
      const cat = selectedCatIdForFocusRef.current;
      // Narrow → broad: programme list → channel list → category grid.
      const target = ch
        ? firstProgRef.current
        : cat !== ALL_CAT_ID
          ? firstChannelRef.current
          : firstCatRef.current;
      requestTvFocus(target);
    }, 200);
    return () => clearTimeout(t);
  }, []));

  // ── Categories ──
  const { data: rawCategories = [], isLoading: catLoading } = useQuery<Category[]>({
    queryKey: ['live-categories', credentials],
    queryFn: () => getXtreamLiveCategories(creds!),
    enabled: !!creds,
    staleTime: 5 * 60_000,
  });

  // ── All live channels (shared cache key with guide.tsx) ──
  const { data: allChannels = [], isLoading: chLoading } = useQuery<Channel[]>({
    queryKey: ['live-channels', null, credentials],
    queryFn: () => getXtreamLiveStreams(creds!),
    enabled: !!creds,
    staleTime: 5 * 60_000,
  });

  // Only catchup-enabled channels
  const catchupChannels = useMemo(
    () => allChannels.filter((c) => (c.tvArchive ?? 0) === 1 && (c.tvArchiveDuration ?? 0) > 0),
    [allChannels],
  );

  // Categories that actually have at least one catchup channel
  const categories = useMemo(() => {
    const withCatchup = new Set(catchupChannels.map((c) => c.groupTitle));
    const filtered = rawCategories.filter((c) => withCatchup.has(c.id));
    const all: Category = { id: ALL_CAT_ID, name: 'All' };
    return [all, ...filtered];
  }, [rawCategories, catchupChannels]);

  // Channels for the selected category
  const visibleChannels = useMemo(() => {
    if (selectedCatId === ALL_CAT_ID) return catchupChannels;
    return catchupChannels.filter((c) => c.groupTitle === selectedCatId);
  }, [catchupChannels, selectedCatId]);

  // ── Archive EPG for selected channel ──
  const { data: programs = [], isLoading: epgLoading } = useQuery<CatchupProgram[]>({
    queryKey: ['catchup-epg', selectedChannel?.id, credentials],
    queryFn: () => getXtreamCatchupEpg(creds!, selectedChannel!.id),
    enabled: !!creds && !!selectedChannel,
    staleTime: 10 * 60_000,
  });

  // Only ended programmes with archive, grouped by day (newest first).
  // Must be declared before dayTabCallbackRefs so the `[days]` dependency
  // array reads a fully initialised binding (no temporal-dead-zone risk).
  const { days, byDay } = useMemo(() => {
    const now = Date.now();
    const playable = programs.filter((p) => p.hasArchive && p.end.getTime() <= now);
    const map = new Map<string, CatchupProgram[]>();
    for (const p of playable) {
      const k = dayKey(p.start);
      if (!map.has(k)) map.set(k, []);
      map.get(k)!.push(p);
    }
    for (const list of map.values()) list.sort((a, b) => b.start.getTime() - a.start.getTime());
    const sortedDays = [...map.keys()].sort((a, b) => {
      const pa = map.get(a)![0]?.start.getTime() ?? 0;
      const pb = map.get(b)![0]?.start.getTime() ?? 0;
      return pb - pa;
    });
    return { days: sortedDays, byDay: map };
  }, [programs]);

  // One stable callback-ref function per day key.  Re-created only when the
  // days array reference changes (i.e. when selectedChannel changes), so React
  // sees the same function between normal re-renders and never detaches /
  // re-attaches — avoiding the state-update loop that an inline arrow would
  // cause.  The setDayTabHandles guard (curr === handle) means state is only
  // written when a handle actually changes.
  // `days` is declared above so the [days] dep array is not in the TDZ.
  const dayTabCallbackRefs = useMemo(
    () =>
      new Map(
        days.map((k) => [
          k,
          (node: View | null) => {
            const handle = node ? findNodeHandle(node) : null;
            setDayTabHandles((prev) => {
              const curr = prev.get(k) ?? null;
              if (curr === handle) return prev;
              const next = new Map(prev);
              if (handle != null) next.set(k, handle);
              else next.delete(k);
              return next;
            });
          },
        ]),
      ),
    [days],
  );

  // Callback ref: assigned to the first programme row in the list.  It keeps
  // firstProgRef in sync for imperative .focus() calls AND updates the state
  // handle that powers nextFocusDown on the day tabs — both are updated after
  // the node actually mounts, avoiding the render-time race.
  const firstProgCallbackRef = useCallback((node: View | null) => {
    firstProgRef.current = node;
    setFirstProgHandle(node ? findNodeHandle(node) : null);
  }, []);

  const activeDay = selectedDay && byDay.has(selectedDay) ? selectedDay : days[0] ?? null;
  const dayPrograms = activeDay ? byDay.get(activeDay) ?? [] : [];

  const handleSelectCat = useCallback((id: string) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedCatId(id);
    setSelectedChannel(null);
    setSelectedDay(null);
    // Auto-advance D-pad focus to the first channel in col 2
    setTimeout(() => { requestTvFocus(firstChannelRef.current); }, 80);
  }, []);

  const handleSelectChannel = useCallback((ch: Channel) => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    setSelectedChannel(ch);
    setSelectedDay(null);
    // Mark that we want to focus the first programme once EPG data arrives
    pendingProgFocusRef.current = true;
  }, []);

  const syncCategoryScroll = useCallback((event: NativeSyntheticEvent<NativeScrollEvent>) => {
    const offset = Math.max(0, event.nativeEvent.contentOffset.y);
    if (
      lastSyncedCategoryOffsetRef.current != null
      && Math.abs(lastSyncedCategoryOffsetRef.current - offset) < 0.5
    ) {
      return;
    }
    lastSyncedCategoryOffsetRef.current = offset;
    categoryListRef.current?.scrollToOffset({ offset, animated: false });
  }, []);

  // Auto-advance D-pad focus to the first programme row once EPG data loads
  useEffect(() => {
    if (pendingProgFocusRef.current && dayPrograms.length > 0) {
      pendingProgFocusRef.current = false;
      setTimeout(() => { requestTvFocus(firstProgRef.current); }, 80);
    }
  }, [dayPrograms]);

  const handlePlay = useCallback((prog: CatchupProgram) => {
    if (!creds || !selectedChannel) return;
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    const durationMin = Math.max(1, Math.round((prog.end.getTime() - prog.start.getTime()) / 60_000));
    // getXtreamCatchupUrls returns [formatB (?utc=), formatA (/timeshift/)] — try B first
    const url = getXtreamCatchupUrls(creds, selectedChannel.id, prog.serverStart, durationMin, prog.startTimestamp)[0];
    router.push({
      pathname: '/player',
      params: {
        url,
        title: `${prog.title} — ${selectedChannel.name}`,
        type: 'catchup',
        logo: selectedChannel.logo ?? '',
        // Pass the known programme duration so the scrubber can show a progress
        // bar — timeshift HLS streams don't expose duration to expo-video.
        knownDuration: String(durationMin * 60),
        // Extra fields needed to regenerate the timeshift URL when the user seeks
        catchupStreamId: selectedChannel.id,
        catchupServerStart: prog.serverStart,
        catchupStartTimestamp: String(prog.startTimestamp),
      },
    });
  }, [creds, selectedChannel, router]);

  const renderCategory = useCallback(({ item, index }: { item: Category; index: number }) => (
    <CategoryRow
      ref={index === 0 ? firstCatRef : undefined}
      cat={item}
      isSelected={item.id === selectedCatId}
      colors={colors}
      // TV: LEFT on the first category item returns D-pad focus to the sidebar.
      nextFocusLeft={Platform.isTV && index === 0 ? sidebarNav.handle : undefined}
      onPress={() => handleSelectCat(item.id)}
    />
  ), [selectedCatId, colors, handleSelectCat]);

  const renderChannel = useCallback(({ item, index }: { item: Channel; index: number }) => (
    <ChannelRow
      ref={index === 0 ? firstChannelRef : undefined}
      ch={item}
      isSelected={item.id === selectedChannel?.id}
      colors={colors}
      onPress={() => handleSelectChannel(item)}
    />
  ), [selectedChannel?.id, colors, handleSelectChannel]);

  // ── Non-Xtream fallback ──
  if (!isXtream) {
    return (
      <View style={[styles.root, { backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center' }]}>
        <Text style={{ fontSize: 36, marginBottom: 10 }}>⏪</Text>
        <Text style={[styles.noSelTitle, { color: colors.foreground }]}>Catch Up unavailable</Text>
        <Text style={[styles.noSelSub, { color: colors.mutedForeground, textAlign: 'center', maxWidth: 400 }]}>
          Catch-up TV requires an Xtream Codes connection. M3U playlists don't support archive playback.
        </Text>
      </View>
    );
  }

  const loading = catLoading || chLoading;

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>

      {/* ══ COL 1: Categories ══ */}
      <View style={[styles.catCol, { borderRightColor: colors.border, paddingTop: insets.top + 4 }]}>
         <Text
           style={[
             styles.colHeader,
             { color: colors.mutedForeground, borderBottomColor: colors.border },
           ]}
         >
           CATEGORIES
         </Text>
        {loading ? (
          <View style={styles.centerFill}><ActivityIndicator color={colors.primary} /></View>
        ) : (
          <FlatList
            ref={categoryListRef}
            data={categories}
            keyExtractor={(c) => c.id}
            renderItem={renderCategory}
            showsVerticalScrollIndicator={false}
            getItemLayout={(_, i) => ({
              length: CATCHUP_GRID_ROW_H,
              offset: CATCHUP_GRID_ROW_H * i,
              index: i,
            })}
            removeClippedSubviews={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 8 }}
          />
        )}
      </View>

      {/* ══ COL 2: Channels ══ */}
      <View style={[styles.chCol, { borderRightColor: colors.border, paddingTop: insets.top + 4 }]}>
        <Text
          style={[
            styles.colHeader,
            { color: colors.mutedForeground, borderBottomColor: colors.border },
          ]}
        >
          CHANNELS
        </Text>
        {loading ? (
          <View style={styles.centerFill}><ActivityIndicator color={colors.primary} /></View>
        ) : visibleChannels.length === 0 ? (
          <View style={styles.centerFill}>
            <Text style={{ color: colors.mutedForeground, fontSize: 12, textAlign: 'center', paddingHorizontal: 16 }}>
              No catch-up channels{'\n'}in this category
            </Text>
          </View>
        ) : (
          <FlatList
            ref={channelListRef}
            data={visibleChannels}
            keyExtractor={(c) => c.id}
            renderItem={renderChannel}
            showsVerticalScrollIndicator={false}
            onScroll={syncCategoryScroll}
            scrollEventThrottle={16}
            getItemLayout={(_, i) => ({
              length: CATCHUP_GRID_ROW_H,
              offset: CATCHUP_GRID_ROW_H * i,
              index: i,
            })}
            removeClippedSubviews={false}
            contentContainerStyle={{ paddingBottom: insets.bottom + 8 }}
          />
        )}
      </View>

      {/* ══ COL 3: Archive programmes ══ */}
      <View style={[styles.progPanel, { paddingTop: insets.top + 4, paddingRight: insets.right + 8 }]}>
        {!selectedChannel ? (
          <View style={styles.noSel}>
            <Text style={{ fontSize: 36, marginBottom: 10 }}>⏪</Text>
            <Text style={[styles.noSelTitle, { color: colors.foreground }]}>Select a channel</Text>
            <Text style={[styles.noSelSub, { color: colors.mutedForeground }]}>
              Pick a channel to browse its archived programmes.
            </Text>
          </View>
        ) : epgLoading ? (
          <View style={styles.centerFill}>
            <ActivityIndicator color={colors.primary} size="large" />
            <Text style={{ color: colors.mutedForeground, fontSize: 12, marginTop: 8 }}>Loading archive…</Text>
          </View>
        ) : days.length === 0 ? (
          <View style={styles.noSel}>
            <Text style={{ fontSize: 30, marginBottom: 10 }}>📭</Text>
            <Text style={[styles.noSelTitle, { color: colors.foreground }]}>No archive found</Text>
            <Text style={[styles.noSelSub, { color: colors.mutedForeground }]}>
              This channel reports catch-up support but returned no replayable programmes.
            </Text>
          </View>
        ) : (
          <>
            {/* Day tabs */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              style={{ flexGrow: 0 }}
              contentContainerStyle={styles.dayTabs}
            >
              {days.map((k, idx) => {
                const first = byDay.get(k)![0];
                const active = k === activeDay;
                return (
                  <FocusablePressable
                    key={k}
                    ref={dayTabCallbackRefs.get(k)}
                    style={[
                      styles.dayTab,
                      { borderColor: colors.border },
                      active && { backgroundColor: '#2563EB', borderColor: '#2563EB' },
                    ]}
                    // Commit the day selection as soon as the tab receives D-pad focus
                    // so left/right navigation between tabs immediately updates the
                    // programme list without requiring an OK press.
                    onFocus={() => { setSelectedDay(k); }}
                    // OK / select press: advance focus directly to the first programme row.
                    onPress={() => {
                      setSelectedDay(k);
                      setTimeout(() => { requestTvFocus(firstProgRef.current); }, 80);
                    }}
                    // D-pad down from the tab strip goes straight to the first programme
                    // row, bypassing the need to press OK first.
                    // firstProgHandle is set by the callback ref once the node is mounted,
                    // so this is always a valid post-mount handle (never a stale one).
                    nextFocusDown={firstProgHandle ?? undefined}
                    // D-pad left/right explicitly routes between adjacent day tabs so the
                    // remote navigates between them without requiring an OK press first.
                    // Handles are populated by updateDayTabHandle once each tab mounts.
                    nextFocusLeft={idx > 0 ? (dayTabHandles.get(days[idx - 1]) ?? undefined) : undefined}
                    nextFocusRight={idx < days.length - 1 ? (dayTabHandles.get(days[idx + 1]) ?? undefined) : undefined}
                  >
                    <Text style={[styles.dayTabText, { color: active ? '#fff' : colors.mutedForeground }]}>
                      {dayLabel(first.start)}
                    </Text>
                  </FocusablePressable>
                );
              })}
            </ScrollView>

            {/* Programme list */}
            <ScrollView
              showsVerticalScrollIndicator={false}
              style={{ flex: 1 }}
              contentContainerStyle={{ paddingBottom: insets.bottom + 8 }}
            >
              {dayPrograms.map((prog, progIdx) => (
                <FocusablePressable
                  key={prog.id}
                  ref={progIdx === 0 ? firstProgCallbackRef : undefined}
                  style={[styles.progRow, { borderBottomColor: colors.border }]}
                  onPress={() => handlePlay(prog)}
                >
                  <View style={styles.progTimeCol}>
                    <Text style={[styles.progTime, { color: colors.mutedForeground }]}>
                      {fmtTime(prog.start)}
                    </Text>
                    <Text style={[styles.progDur, { color: colors.mutedForeground }]}>
                      {Math.round((prog.end.getTime() - prog.start.getTime()) / 60_000)}m
                    </Text>
                  </View>
                  <View style={{ flex: 1, minWidth: 0 }}>
                    <Text style={[styles.progTitle, { color: colors.foreground }]} numberOfLines={1}>
                      {prog.title}
                    </Text>
                    {prog.description ? (
                      <Text style={[styles.progDesc, { color: colors.mutedForeground }]} numberOfLines={2}>
                        {prog.description}
                      </Text>
                    ) : null}
                  </View>
                  <Text style={{ color: '#3B82F6', fontSize: 16, marginLeft: 8 }}>▶</Text>
                </FocusablePressable>
              ))}
            </ScrollView>
          </>
        )}
      </View>
    </View>
  );
}

// ─── Styles ───────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  root: { flex: 1, flexDirection: 'row' },
  centerFill: { flex: 1, alignItems: 'center', justifyContent: 'center' },

  colHeader: {
    fontSize: 10, fontFamily: 'Inter_600SemiBold', letterSpacing: 1.5,
    paddingHorizontal: 12, paddingVertical: 8,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },

  // Col 1 — categories
  catCol: { width: '20%', borderRightWidth: StyleSheet.hairlineWidth },
  catRow: {
    height: CATCHUP_GRID_ROW_H,
    paddingHorizontal: 12,
    justifyContent: 'center',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
  },
  catRowText: { fontSize: 13, fontFamily: 'Inter_500Medium' },

  // Col 2 — channels
  chCol: { width: '30%', borderRightWidth: StyleSheet.hairlineWidth },
  chRow: {
    flexDirection: 'row', alignItems: 'center', gap: 10,
    height: CATCHUP_GRID_ROW_H,
    paddingHorizontal: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderLeftWidth: 3,
    borderLeftColor: 'transparent',
  },
  chLogo: {
    width: 36, height: 28, borderRadius: 4, overflow: 'hidden',
    justifyContent: 'center', alignItems: 'center', flexShrink: 0,
  },
  chInitials: { fontSize: 10, fontFamily: 'Inter_700Bold' },
  chName: { fontSize: 13, fontFamily: 'Inter_500Medium' },
  chSub: { fontSize: 10, fontFamily: 'Inter_400Regular', marginTop: 2 },

  // Col 3 — programmes
  progPanel: { flex: 1, paddingLeft: 14 },
  dayTabs: { flexDirection: 'row', gap: 8, paddingVertical: 8 },
  dayTab: {
    paddingHorizontal: 14, paddingVertical: 7,
    borderRadius: 8, borderWidth: 1,
  },
  dayTabText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },

  progRow: {
    flexDirection: 'row', alignItems: 'center',
    paddingVertical: 10, borderBottomWidth: StyleSheet.hairlineWidth,
  },
  progTimeCol: { width: 74, flexShrink: 0 },
  progTime: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  progDur: { fontSize: 10.5, fontFamily: 'Inter_400Regular', marginTop: 1 },
  progTitle: { fontSize: 13, fontFamily: 'Inter_600SemiBold' },
  progDesc: { fontSize: 11.5, fontFamily: 'Inter_400Regular', marginTop: 2, lineHeight: 15 },

  noSel: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 30 },
  noSelTitle: { fontSize: 17, fontFamily: 'Inter_700Bold', marginBottom: 6 },
  noSelSub: { fontSize: 12.5, fontFamily: 'Inter_400Regular', textAlign: 'center', lineHeight: 18 },
});
