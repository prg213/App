import React, { useCallback, useEffect, useRef, useState } from 'react';
import { FocusablePressable } from '@/components/FocusablePressable';
import {
  Alert,
  DeviceEventEmitter,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  View,
} from 'react-native';
import * as Haptics from 'expo-haptics';
import { useFocusEffect, useRouter } from 'expo-router';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';
import { useAppContext } from '@/context/AppContext';
import { useParentalContext, RATING_OPTIONS } from '@/context/ParentalContext';
import { PinPad } from '@/components/PinPad';
import {
  getXtreamAccountInfo,
  parseXtreamCredsFromM3u,
} from '@/services/xtreamApi';
import { StorageService } from '@/services/storage';
import { CommunityModal } from '@/components/CommunityModal';
import { ConfirmModal } from '@/components/ConfirmModal';
import { UpdateModal } from '@/components/UpdateModal';
import { rescheduleRemindersForLeadTime } from '@/services/reminderReschedule';
import { clearReminderRefreshCache } from '@/services/reminderUrlCache';
import { checkForUpdate, CURRENT_BUILD, type UpdateInfo } from '@/services/updateService';
import type { MaxRating } from '@/types';
import { requestTvFocus } from '@/lib/tvFocus';
import { overrideDeviceMac } from '@/services/macAddress';

const LEAD_TIME_OPTIONS: { value: 5 | 10 | 15; label: string }[] = [
  { value: 5,  label: '5 minutes before' },
  { value: 10, label: '10 minutes before' },
  { value: 15, label: '15 minutes before' },
];

type PinFlowKind =
  | 'set-first'   // no existing PIN — set a new one
  | 'verify-to-change-rating'
  | 'verify-to-toggle-lock'
  | 'verify-to-change-pin'
  | 'change-pin'  // after old PIN verified, enter new PIN
  | 'verify-to-disable'
  | 'verify-to-blocked-channels'
  | null;

export default function SettingsScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const queryClient = useQueryClient();
  const router = useRouter();
  const { credentials, deviceMac, logout } = useAppContext();
  const {
    isPinSet,
    lockEnabled,
    maxRating,
    blockedChannels,
    verifyPin,
    setPin,
    disablePin,
    setLockEnabled,
    setMaxRating,
  } = useParentalContext();
  const [loggingOut, setLoggingOut] = useState(false);
  const [showCommunity, setShowCommunity] = useState(false);
  const [reminderLeadMins, setReminderLeadMins] = useState<5 | 10 | 15>(5);
  const [showLeadTimeSheet, setShowLeadTimeSheet] = useState(false);
  const [prefAudioLang, setPrefAudioLang] = useState<string>('');
  const [showAudioLangSheet, setShowAudioLangSheet] = useState(false);
  const [prefSubtitleLang, setPrefSubtitleLang] = useState<string>('');
  const [showSubtitleLangSheet, setShowSubtitleLangSheet] = useState(false);
  const [checkingUpdate, setCheckingUpdate] = useState(false);
  const [pendingUpdate, setPendingUpdate] = useState<UpdateInfo | null>(null);
  const [showMacRestore, setShowMacRestore] = useState(false);
  const [macRestoreInput, setMacRestoreInput] = useState('');
  const [macRestoreError, setMacRestoreError] = useState('');

  const handleMacRestore = useCallback(async () => {
    try {
      await overrideDeviceMac(macRestoreInput.trim());
      setShowMacRestore(false);
      Alert.alert('MAC Restored', 'Force-close and reopen the app for the new MAC to take effect everywhere.');
    } catch (e: unknown) {
      setMacRestoreError(e instanceof Error ? e.message : 'Invalid MAC');
    }
  }, [macRestoreInput]);

  const handleCheckUpdate = async () => {
    if (checkingUpdate) return;
    Haptics.selectionAsync();
    setCheckingUpdate(true);
    try {
      const info = await checkForUpdate();
      if (info) {
        setPendingUpdate(info);
      } else {
        Alert.alert(
          'Up to date',
          CURRENT_BUILD === 0
            ? 'Update checks are not available in dev builds.'
            : `You're on the latest version (build ${CURRENT_BUILD}).`,
          [{ text: 'OK' }],
        );
      }
    } catch {
      Alert.alert('Check failed', 'Could not reach the update server. Check your connection and try again.', [{ text: 'OK' }]);
    } finally {
      setCheckingUpdate(false);
    }
  };

  const LANG_OPTIONS = [
    { value: '', label: 'Auto (stream default)' },
    { value: 'en', label: 'English' },
    { value: 'fr', label: 'French' },
    { value: 'de', label: 'German' },
    { value: 'es', label: 'Spanish' },
    { value: 'ar', label: 'Arabic' },
    { value: 'it', label: 'Italian' },
    { value: 'pt', label: 'Portuguese' },
    { value: 'ru', label: 'Russian' },
    { value: 'tr', label: 'Turkish' },
    { value: 'pl', label: 'Polish' },
    { value: 'nl', label: 'Dutch' },
  ];
  const AUDIO_LANG_OPTIONS = LANG_OPTIONS;

  useEffect(() => {
    StorageService.getReminderLeadMins().then((v) => setReminderLeadMins(v as 5 | 10 | 15));
    StorageService.getPrefAudioLanguage().then((v) => setPrefAudioLang(v ?? ''));
    StorageService.getPrefSubtitleLang().then((v) => setPrefSubtitleLang(v ?? ''));
  }, []);

  const handleLeadTimeSelect = async (value: 5 | 10 | 15) => {
    Haptics.selectionAsync();
    await StorageService.setReminderLeadMins(value);
    setReminderLeadMins(value);
    setShowLeadTimeSheet(false);

    // #99: Re-schedule all future reminders with the new lead time
    const { tooSoon } = await rescheduleRemindersForLeadTime();

    // #114: Tell the Reminders tab to re-render cards with the new lead time.
    // This is a no-op when the tab is not mounted; when it is mounted (e.g. on
    // a tablet split-view) useFocusEffect(load) will pick up the signal.
    DeviceEventEmitter.emit('reminders:changed');

    // #135: Instant badge update on split-view / always-visible layouts.
    // Distinct from 'reminders:changed' so the listener only refreshes the
    // lead-time state and does NOT trigger a full reminder list reload.
    DeviceEventEmitter.emit('leadtime:changed');

    // #110: Warn if any reminders start too soon to fire at the new lead time
    if (tooSoon > 0) {
      Alert.alert(
        'Some reminders not updated',
        `${tooSoon} reminder${tooSoon > 1 ? 's start' : ' starts'} too soon to fire ${value} minute${value > 1 ? 's' : ''} early. ${tooSoon > 1 ? 'They' : 'It'} will still appear on-screen.`,
        [{ text: 'OK' }],
      );
    }
  };

  // PIN modal state
  const [pinFlow, setPinFlow] = useState<PinFlowKind>(null);
  const [pendingRating, setPendingRating] = useState<MaxRating | null>(null);
  const [pendingLock, setPendingLock] = useState<boolean | null>(null);
  const [showRatingSheet, setShowRatingSheet] = useState(false);

  // ── Confirmation dialog (TV-safe replacement for Alert.alert destructive) ───
  // A single modal instance driven by this state; swapped out per-action.
  // openerRef is stored so focus returns to the triggering row on close.
  const [confirmDialog, setConfirmDialog] = useState<{
    title: string;
    message: string;
    confirmLabel: string;
    onConfirm: () => void;
  } | null>(null);
  // Stores the View node of whichever row opened the current confirm dialog so
  // ConfirmModal can restore D-pad focus when it closes.  Set synchronously
  // before each setConfirmDialog() call so the ref is always up-to-date.
  const confirmOpenerRef = useRef<View | null>(null);
  // Per-row refs for the four rows that open the confirm dialog.
  const clearHistoryRowRef  = useRef<View>(null);
  const clearRecentRowRef   = useRef<View>(null);
  const clearSearchRowRef   = useRef<View>(null);
  const logoutRowRef        = useRef<View>(null);

  // ── TV: D-pad focus restoration after picker sheets / PIN modal close ──────
  // Each opener FocusablePressable stores a ref; a useEffect per sheet watches
  // the show-flag and, when the sheet closes (true → false), calls focus() on
  // the opener row so the user doesn't have to re-navigate from the top.
  const audioLangRowRef = useRef<View>(null);
  const subtitleLangRowRef = useRef<View>(null);
  const leadTimeRowRef = useRef<View>(null);
  const ratingRowRef = useRef<View>(null);
  const setPinRowRef = useRef<View>(null);
  // TV: ref to the Community row — passed as openerRef to CommunityModal so
  // focus returns here after the modal closes.
  const communityRowRef = useRef<View>(null);
  // TV: ref to the initially-focused item in each picker sheet.
  // Set on the currently-selected (or first) row, then called in Modal onShow.
  // Replaces hasTVPreferredFocus which re-fires requestFocus on every re-render
  // and causes focus-racing on Fire OS.
  const firstAudioOptRef  = useRef<View>(null);
  const firstSubOptRef    = useRef<View>(null);
  const firstLeadOptRef   = useRef<View>(null);
  const firstRatingOptRef = useRef<View>(null);

  // TV: focus the first action row (Refresh All Content) whenever the Settings
  // tab becomes active.  Replaces hasTVPreferredFocus to avoid Fire OS re-render
  // requestFocus races.
  const firstSettingsRowRef = useRef<View>(null);
  useFocusEffect(useCallback(() => {
    if (!Platform.isTV) return;
    const t = setTimeout(() => requestTvFocus(firstSettingsRowRef.current), 150);
    return () => clearTimeout(t);
  }, []));

  const audioLangWasOpen = useRef(false);
  useEffect(() => {
    if (!Platform.isTV) return;
    if (showAudioLangSheet) { audioLangWasOpen.current = true; return; }
    if (audioLangWasOpen.current) { audioLangWasOpen.current = false; setTimeout(() => requestTvFocus(audioLangRowRef.current), 150); }
  }, [showAudioLangSheet]);

  const subtitleLangWasOpen = useRef(false);
  useEffect(() => {
    if (!Platform.isTV) return;
    if (showSubtitleLangSheet) { subtitleLangWasOpen.current = true; return; }
    if (subtitleLangWasOpen.current) { subtitleLangWasOpen.current = false; setTimeout(() => requestTvFocus(subtitleLangRowRef.current), 150); }
  }, [showSubtitleLangSheet]);

  const leadTimeWasOpen = useRef(false);
  useEffect(() => {
    if (!Platform.isTV) return;
    if (showLeadTimeSheet) { leadTimeWasOpen.current = true; return; }
    if (leadTimeWasOpen.current) { leadTimeWasOpen.current = false; setTimeout(() => requestTvFocus(leadTimeRowRef.current), 150); }
  }, [showLeadTimeSheet]);

  const ratingWasOpen = useRef(false);
  useEffect(() => {
    if (!Platform.isTV) return;
    if (showRatingSheet) { ratingWasOpen.current = true; return; }
    if (ratingWasOpen.current) { ratingWasOpen.current = false; setTimeout(() => requestTvFocus(ratingRowRef.current), 150); }
  }, [showRatingSheet]);

  const pinWasOpen = useRef(false);
  useEffect(() => {
    if (!Platform.isTV) return;
    if (pinFlow !== null) { pinWasOpen.current = true; return; }
    if (pinWasOpen.current) { pinWasOpen.current = false; setTimeout(() => requestTvFocus(setPinRowRef.current), 150); }
  }, [pinFlow]);

  // Resolve Xtream credentials — either directly (xtream type) or parsed from M3U URL
  const xtreamCreds =
    credentials?.type === 'xtream' && credentials.host && credentials.username && credentials.password
      ? { host: credentials.host, username: credentials.username, password: credentials.password }
      : credentials?.type === 'm3u' && credentials.m3uUrl
      ? parseXtreamCredsFromM3u(credentials.m3uUrl)
      : null;

  const { data: accountInfo, isLoading: accountLoading } = useQuery({
    queryKey: ['account-info', credentials],
    queryFn: () => getXtreamAccountInfo(xtreamCreds!),
    enabled: !!xtreamCreds,
    staleTime: 10 * 60_000,
    retry: 1,
  });

  const handleRefreshContent = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    queryClient.invalidateQueries({ queryKey: ['live-channels'] });
    queryClient.invalidateQueries({ queryKey: ['live-categories'] });
    queryClient.invalidateQueries({ queryKey: ['vod-streams'] });
    queryClient.invalidateQueries({ queryKey: ['vod-categories'] });
    queryClient.invalidateQueries({ queryKey: ['series-list'] });
    queryClient.invalidateQueries({ queryKey: ['series-categories'] });
    Alert.alert('Content Refreshed', 'Channels, movies and series will reload on next view.');
  };

  const handleRefreshEPG = () => {
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    queryClient.invalidateQueries({ queryKey: ['xmltv-epg'] });
    Alert.alert('EPG Refreshed', 'TV guide data will reload. This may take a moment.');
  };

  const handleLogout = () => {
    confirmOpenerRef.current = logoutRowRef.current;
    setConfirmDialog({
      title: 'Unlink Device',
      message: 'This will remove your IPTV credentials and return you to the activation screen.',
      confirmLabel: 'Unlink Device',
      onConfirm: async () => {
        setConfirmDialog(null);
        setLoggingOut(true);
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        clearReminderRefreshCache(); // #126: reset so new credentials get a fresh URL check
        await logout();
      },
    });
  };

  // ── Parental controls actions ──────────────────────────────────────────────

  const handleRatingPress = (rating: MaxRating) => {
    if (rating === maxRating) { setShowRatingSheet(false); return; }
    if (isPinSet) {
      setPendingRating(rating);
      setShowRatingSheet(false);
      setPinFlow('verify-to-change-rating');
    } else {
      setMaxRating(rating);
      setShowRatingSheet(false);
    }
  };

  const handleLockToggle = (val: boolean) => {
    if (!isPinSet && val) {
      // Must set a PIN first
      setPinFlow('set-first');
      setPendingLock(true);
      return;
    }
    if (isPinSet) {
      setPendingLock(val);
      setPinFlow('verify-to-toggle-lock');
      return;
    }
    setLockEnabled(val);
  };

  const handleSetPinPress = () => {
    if (isPinSet) {
      setPinFlow('verify-to-change-pin');
    } else {
      setPinFlow('set-first');
    }
  };

  const handleDisablePinPress = () => {
    if (!isPinSet) return;
    setPinFlow('verify-to-disable');
  };

  const handleBlockedChannelsPress = () => {
    if (isPinSet) {
      setPinFlow('verify-to-blocked-channels');
    } else {
      router.push('/blocked-channels');
    }
  };

  const handleClearHistory = () => {
    confirmOpenerRef.current = clearHistoryRowRef.current;
    setConfirmDialog({
      title: 'Clear Watch History',
      message: 'Remove all watched items? This cannot be undone.',
      confirmLabel: 'Clear All',
      onConfirm: () => {
        setConfirmDialog(null);
        StorageService.clearHistory().then(() => {
          DeviceEventEmitter.emit('history:cleared');
        }).catch(() => {});
      },
    });
  };

  const handleClearRecentChannels = () => {
    confirmOpenerRef.current = clearRecentRowRef.current;
    setConfirmDialog({
      title: 'Clear Recent Channels',
      message: 'Remove all recently-watched channels?',
      confirmLabel: 'Clear',
      onConfirm: () => {
        setConfirmDialog(null);
        StorageService.clearRecentChannels().catch(() => {});
      },
    });
  };

  // PIN modal success callbacks
  const onPinSuccess = async (pin: string) => {
    if (pinFlow === 'set-first') {
      await setPin(pin);
      // If we were pending a lock toggle, apply it
      if (pendingLock !== null) {
        await setLockEnabled(pendingLock);
        setPendingLock(null);
      }
    } else if (pinFlow === 'verify-to-change-rating' && pendingRating !== null) {
      // Pin was verified (PinPad's verify fn returns true) — now apply the change
      await setMaxRating(pendingRating);
      setPendingRating(null);
    } else if (pinFlow === 'verify-to-toggle-lock' && pendingLock !== null) {
      await setLockEnabled(pendingLock);
      setPendingLock(null);
    } else if (pinFlow === 'verify-to-change-pin') {
      // Old PIN verified — now set new PIN
      setPinFlow('change-pin');
      return; // don't close modal yet
    } else if (pinFlow === 'change-pin') {
      // New PIN set
      await setPin(pin);
    } else if (pinFlow === 'verify-to-disable') {
      const ok = await disablePin(pin);
      if (!ok) return; // shouldn't happen — PinPad's verify already checked
    } else if (pinFlow === 'verify-to-blocked-channels') {
      setPinFlow(null);
      router.push('/blocked-channels');
      return;
    }
    setPinFlow(null);
  };

  const ratingLabel = RATING_OPTIONS.find((r) => r.value === maxRating)?.label ?? 'All content';

  const typeLabel = credentials?.type === 'xtream' ? 'Xtream Codes' : 'M3U Playlist';
  const typeColor = credentials?.type === 'xtream' ? '#3B82F6' : '#22C55E';

  function InfoRow({ label, value, dimValue }: { label: string; value?: string | null; dimValue?: boolean }) {
    if (!value) return null;
    return (
      <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
        <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>{label}</Text>
        <Text
          style={[styles.infoValue, { color: dimValue ? colors.mutedForeground : colors.foreground }]}
          numberOfLines={1}
          selectable
        >
          {value}
        </Text>
      </View>
    );
  }

  function ActionRow({ title, sub, icon, onPress, destructive, refProp }: {
    title: string; sub?: string; icon: string; onPress: () => void; destructive?: boolean;
    /** Ref forwarded to the underlying FocusablePressable — used by useFocusEffect
     *  to restore D-pad focus on screen entry without hasTVPreferredFocus races. */
    refProp?: React.RefObject<View | null>;
  }) {
    return (
      <FocusablePressable
        ref={refProp}
        style={[styles.actionRow, { borderBottomColor: colors.border }]}
        onPress={onPress}
      >
        <View style={{ flex: 1 }}>
          <Text style={[styles.actionTitle, { color: destructive ? colors.destructive : colors.foreground }]}>{title}</Text>
          {sub ? <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>{sub}</Text> : null}
        </View>
        <Text style={{ color: destructive ? colors.destructive : colors.mutedForeground, fontSize: 18 }}>{icon}</Text>
      </FocusablePressable>
    );
  }

  // Expiry date — from account info query, or from M3U URL if parseable
  const expiry = accountInfo?.expDate ?? null;
  const expiryLoading = accountLoading && !!xtreamCreds;

  // Determine which PIN pad title/mode to show
  const pinModalTitle = () => {
    switch (pinFlow) {
      case 'set-first': return 'Set a PIN';
      case 'change-pin': return 'Enter new PIN';
      case 'verify-to-change-rating':
      case 'verify-to-toggle-lock':
      case 'verify-to-change-pin':
      case 'verify-to-disable':
      case 'verify-to-blocked-channels':
        return 'Confirm your PIN';
      default: return 'Enter PIN';
    }
  };

  const isVerifyMode = pinFlow === 'verify-to-change-rating' ||
    pinFlow === 'verify-to-toggle-lock' ||
    pinFlow === 'verify-to-change-pin' ||
    pinFlow === 'verify-to-disable' ||
    pinFlow === 'verify-to-blocked-channels';

  return (
    <View style={[styles.container, { backgroundColor: colors.background }]}>
      {/* Left: Connection info */}
      <ScrollView
        style={[styles.left, { borderRightColor: colors.border }]}
        contentContainerStyle={[styles.leftContent, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 16 }]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.screenTitle, { color: colors.foreground }]}>Settings</Text>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>CONNECTION</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {/* Type badge */}
          <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Type</Text>
            <View style={[styles.typeBadge, { backgroundColor: `${typeColor}20` }]}>
              <Text style={[styles.typeBadgeText, { color: typeColor }]}>{typeLabel}</Text>
            </View>
          </View>

          {/* Xtream: show username only (hide host + password label) */}
          {credentials?.type === 'xtream' && (
            <InfoRow label="Username" value={credentials.username} />
          )}

          {/* M3U: show truncated URL */}
          {credentials?.type === 'm3u' && credentials.m3uUrl && (
            <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>M3U URL</Text>
              <Text style={[styles.infoValue, { color: colors.mutedForeground }]} numberOfLines={1}>
                {credentials.m3uUrl.length > 40
                  ? credentials.m3uUrl.slice(0, 20) + '…' + credentials.m3uUrl.slice(-18)
                  : credentials.m3uUrl}
              </Text>
            </View>
          )}

          {/* Expiry date */}
          <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Expires</Text>
            {expiryLoading ? (
              <Text style={[styles.infoValue, { color: colors.mutedForeground }]}>Loading…</Text>
            ) : expiry ? (
              <Text style={[styles.infoValue, { color: colors.foreground }]}>{expiry}</Text>
            ) : (
              <Text style={[styles.infoValue, { color: colors.mutedForeground }]}>—</Text>
            )}
          </View>

          {/* Status */}
          {accountInfo?.status && (
            <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
              <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Status</Text>
              <View style={[styles.typeBadge, {
                backgroundColor: accountInfo.status === 'Active' ? 'rgba(34,197,94,0.15)' : 'rgba(239,68,68,0.15)',
              }]}>
                <Text style={[styles.typeBadgeText, {
                  color: accountInfo.status === 'Active' ? '#22C55E' : '#EF4444',
                }]}>{accountInfo.status}</Text>
              </View>
            </View>
          )}

          {/* Connections */}
          {accountInfo?.maxConnections != null && (
            <View style={styles.infoRow}>
              <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Connections</Text>
              <Text style={[styles.infoValue, { color: colors.foreground }]}>
                {accountInfo.activeConnections ?? 0} / {accountInfo.maxConnections}
              </Text>
            </View>
          )}
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>DEVICE</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.infoRow}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>MAC Address</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
              <Text style={[styles.macText, { color: colors.foreground }]} selectable>{deviceMac}</Text>
              <Pressable onPress={() => { setMacRestoreInput(''); setMacRestoreError(''); setShowMacRestore(true); }}>
                <Text style={{ color: colors.primary ?? '#6366F1', fontSize: 11, fontFamily: 'Inter_500Medium' }}>Restore</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </ScrollView>

      {/* Right: Actions */}
      <ScrollView
        style={styles.right}
        contentContainerStyle={[styles.rightContent, { paddingTop: insets.top + 12, paddingBottom: insets.bottom + 16, paddingRight: insets.right + 16 }]}
        showsVerticalScrollIndicator={false}
      >
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>CONTENT</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <ActionRow
            title="Refresh All Content"
            sub="Reload channels, movies & series"
            icon="↻"
            onPress={handleRefreshContent}
            refProp={firstSettingsRowRef}
          />
          <ActionRow
            title="Refresh TV Guide (EPG)"
            sub="Reload electronic programme guide"
            icon="📡"
            onPress={handleRefreshEPG}
          />
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>HISTORY</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <ActionRow
            title="Watch History"
            sub="View and remove individual watched items"
            icon="🕐"
            onPress={() => router.push('/watch-history')}
          />
          <ActionRow
            title="Clear Watch History"
            sub="Remove all watched items"
            icon="🗑️"
            onPress={handleClearHistory}
            refProp={clearHistoryRowRef}
          />
          <ActionRow
            title="Clear Recent Channels"
            sub="Remove the recently-watched channel rail"
            icon="⏮"
            onPress={handleClearRecentChannels}
            refProp={clearRecentRowRef}
          />
          <ActionRow
            title="Clear Search History"
            sub="Remove saved recent searches"
            icon="🔍"
            refProp={clearSearchRowRef}
            onPress={() => {
              confirmOpenerRef.current = clearSearchRowRef.current;
              setConfirmDialog({
                title: 'Clear Search History',
                message: 'Remove all saved recent searches?',
                confirmLabel: 'Clear',
                onConfirm: () => {
                  setConfirmDialog(null);
                  StorageService.clearRecentSearches();
                  DeviceEventEmitter.emit('search-history:cleared');
                },
              });
            }}
          />
        </View>

        {/* ── Playback ── */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>PLAYBACK</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <FocusablePressable
            style={[styles.actionRow, { borderBottomColor: colors.border }]}
            ref={audioLangRowRef}
            onPress={() => setShowAudioLangSheet(true)}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>Preferred Audio Language</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {LANG_OPTIONS.find((o) => o.value === prefAudioLang)?.label ?? 'Auto (stream default)'}
              </Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>🔊</Text>
          </FocusablePressable>
          <FocusablePressable
            style={[styles.actionRow, { borderBottomWidth: 0 }]}
            ref={subtitleLangRowRef}
            onPress={() => setShowSubtitleLangSheet(true)}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>Preferred Subtitle Language</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {LANG_OPTIONS.find((o) => o.value === prefSubtitleLang)?.label ?? 'Auto (stream default)'}
              </Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>CC</Text>
          </FocusablePressable>
        </View>

        {/* ── Notifications ── */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>NOTIFICATIONS</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <FocusablePressable
            style={[styles.actionRow, { borderBottomWidth: 0 }]}
            ref={leadTimeRowRef}
            onPress={() => setShowLeadTimeSheet(true)}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>Reminder Lead Time</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {LEAD_TIME_OPTIONS.find((o) => o.value === reminderLeadMins)?.label ?? '5 minutes before'}
              </Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>⏰</Text>
          </FocusablePressable>
        </View>

        {/* ── Parental Controls ── */}
        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>PARENTAL CONTROLS</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          {/* Content Rating picker */}
          <FocusablePressable
            style={[styles.actionRow, { borderBottomColor: colors.border }]}
            ref={ratingRowRef}
            onPress={() => setShowRatingSheet(true)}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>Content Rating</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>{ratingLabel}</Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>›</Text>
          </FocusablePressable>

          {/* App Lock toggle — FocusablePressable makes the whole row a D-pad
              target on Fire TV so pressing OK toggles the lock without needing
              to focus the Switch widget directly. */}
          <FocusablePressable
            style={[styles.actionRow, { borderBottomColor: colors.border }]}
            onPress={() => handleLockToggle(!lockEnabled)}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>App Lock PIN</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {lockEnabled ? 'Locked after 2 min in background' : 'Disabled'}
              </Text>
            </View>
            <Switch
              value={lockEnabled}
              onValueChange={handleLockToggle}
              trackColor={{ true: '#3B82F6' }}
              thumbColor="#fff"
              focusable={false}
            />
          </FocusablePressable>

          {/* Set / Change PIN */}
          <FocusablePressable
            ref={setPinRowRef}
            style={[styles.actionRow, { borderBottomColor: colors.border }]}
            onPress={handleSetPinPress}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>
                {isPinSet ? 'Change PIN' : 'Set PIN'}
              </Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {isPinSet ? 'Update your 4-digit PIN' : 'Protect parental settings'}
              </Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>🔒</Text>
          </FocusablePressable>

          {/* Blocked Channels */}
          <FocusablePressable
            style={[styles.actionRow, { borderBottomColor: colors.border }]}
            onPress={handleBlockedChannelsPress}
          >
            <View style={{ flex: 1 }}>
              <Text style={[styles.actionTitle, { color: colors.foreground }]}>Blocked Channels</Text>
              <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>
                {blockedChannels.length > 0
                  ? `${blockedChannels.length} channel${blockedChannels.length === 1 ? '' : 's'} blocked`
                  : 'Hide specific Live TV channels'}
              </Text>
            </View>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>🚫</Text>
          </FocusablePressable>

          {/* Remove PIN */}
          {isPinSet && (
            <FocusablePressable style={styles.actionRow} onPress={handleDisablePinPress}>
              <View style={{ flex: 1 }}>
                <Text style={[styles.actionTitle, { color: colors.destructive }]}>Remove PIN</Text>
                <Text style={[styles.actionSub, { color: colors.mutedForeground }]}>Disable all PIN protection</Text>
              </View>
              <Text style={{ color: colors.destructive, fontSize: 18 }}>✕</Text>
            </FocusablePressable>
          )}
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>SUPPORT</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <ActionRow
            title="Join our Community"
            sub="Chat with other StreamVault users on Telegram"
            icon="💬"
            onPress={() => setShowCommunity(true)}
            refProp={communityRowRef}
          />
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ABOUT</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>App</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>StreamVault IPTV</Text>
          </View>
          <View style={[styles.infoRow, { borderBottomColor: colors.border }]}>
            <Text style={[styles.infoLabel, { color: colors.mutedForeground }]}>Build</Text>
            <Text style={[styles.infoValue, { color: colors.foreground }]}>
              {CURRENT_BUILD > 0 ? `#${CURRENT_BUILD}` : 'Dev'}
            </Text>
          </View>
          <FocusablePressable
            style={[styles.actionRow, { borderBottomWidth: 0 }]}
            onPress={handleCheckUpdate}
            disabled={checkingUpdate}
          >
            <Text style={[styles.actionTitle, { color: colors.foreground }]}>
              {checkingUpdate ? 'Checking…' : 'Check for Update'}
            </Text>
            <Text style={{ color: colors.mutedForeground, fontSize: 18 }}>🔄</Text>
          </FocusablePressable>
        </View>

        <Text style={[styles.sectionLabel, { color: colors.mutedForeground }]}>ACCOUNT</Text>
        <View style={[styles.card, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <FocusablePressable ref={logoutRowRef} style={styles.logoutRow} onPress={handleLogout} disabled={loggingOut}>
            <Text style={[styles.logoutText, { color: colors.destructive }]}>Logout / Unlink Device</Text>
          </FocusablePressable>
        </View>
      </ScrollView>

      {/* ── Update modal ── */}
      {pendingUpdate && (
        <UpdateModal update={pendingUpdate} onDismiss={() => setPendingUpdate(null)} />
      )}

      {/* ── Preferred Audio Language picker sheet ── */}
      <Modal
        visible={showAudioLangSheet}
        transparent
        animationType="slide"
        onShow={() => {
          if (Platform.isTV) setTimeout(() => requestTvFocus(firstAudioOptRef.current), 80);
        }}
        onRequestClose={() => setShowAudioLangSheet(false)}
      >
        {/* focusable={false}: BACK closes via onRequestClose; this prevents the
            backdrop from stealing D-pad focus away from the option rows */}
        <Pressable
          style={styles.sheetBackdrop}
          onPress={() => setShowAudioLangSheet(false)}
          focusable={false}
        />
        <View style={[styles.sheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.sheetHandle} />
          <Text style={[styles.sheetTitle, { color: colors.mutedForeground }]}>PREFERRED AUDIO LANGUAGE</Text>
          {AUDIO_LANG_OPTIONS.map((opt, index) => (
            <FocusablePressable
              key={opt.value}
              ref={Platform.isTV && (prefAudioLang ? opt.value === prefAudioLang : index === 0) ? firstAudioOptRef : undefined}
              style={[styles.sheetRow, { borderBottomColor: colors.border }]}
              onPress={async () => {
                Haptics.selectionAsync();
                await StorageService.setPrefAudioLanguage(opt.value);
                setPrefAudioLang(opt.value);
                setShowAudioLangSheet(false);
              }}
            >
              <Text style={[styles.sheetRowText, { color: colors.foreground }]}>{opt.label}</Text>
              {prefAudioLang === opt.value && <Text style={{ color: '#3B82F6', fontSize: 18 }}>✓</Text>}
            </FocusablePressable>
          ))}
        </View>
      </Modal>

      {/* ── Preferred Subtitle Language picker sheet ── */}
      <Modal
        visible={showSubtitleLangSheet}
        transparent
        animationType="slide"
        onShow={() => {
          if (Platform.isTV) setTimeout(() => requestTvFocus(firstSubOptRef.current), 80);
        }}
        onRequestClose={() => setShowSubtitleLangSheet(false)}
      >
        <Pressable
          style={styles.sheetBackdrop}
          onPress={() => setShowSubtitleLangSheet(false)}
          focusable={false}
        />
        <View style={[styles.sheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.sheetHandle} />
          <Text style={[styles.sheetTitle, { color: colors.mutedForeground }]}>PREFERRED SUBTITLE LANGUAGE</Text>
          {LANG_OPTIONS.map((opt, index) => (
            <FocusablePressable
              key={opt.value}
              ref={Platform.isTV && (prefSubtitleLang ? opt.value === prefSubtitleLang : index === 0) ? firstSubOptRef : undefined}
              style={[styles.sheetRow, { borderBottomColor: colors.border }]}
              onPress={async () => {
                Haptics.selectionAsync();
                await StorageService.setPrefSubtitleLang(opt.value);
                setPrefSubtitleLang(opt.value);
                setShowSubtitleLangSheet(false);
              }}
            >
              <Text style={[styles.sheetRowText, { color: colors.foreground }]}>{opt.label}</Text>
              {prefSubtitleLang === opt.value && <Text style={{ color: '#3B82F6', fontSize: 18 }}>✓</Text>}
            </FocusablePressable>
          ))}
        </View>
      </Modal>

      {/* ── Reminder lead time picker sheet ── */}
      <Modal
        visible={showLeadTimeSheet}
        transparent
        animationType="slide"
        onShow={() => {
          if (Platform.isTV) setTimeout(() => requestTvFocus(firstLeadOptRef.current), 80);
        }}
        onRequestClose={() => setShowLeadTimeSheet(false)}
      >
        <Pressable
          style={styles.sheetBackdrop}
          onPress={() => setShowLeadTimeSheet(false)}
          focusable={false}
        />
        <View style={[styles.sheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.sheetHandle} />
          <Text style={[styles.sheetTitle, { color: colors.mutedForeground }]}>REMINDER LEAD TIME</Text>
          {LEAD_TIME_OPTIONS.map((opt) => (
            <FocusablePressable
              key={opt.value}
              ref={Platform.isTV && opt.value === reminderLeadMins ? firstLeadOptRef : undefined}
              style={[styles.sheetRow, { borderBottomColor: colors.border }]}
              onPress={() => handleLeadTimeSelect(opt.value)}
            >
              <Text style={[styles.sheetRowText, { color: colors.foreground }]}>{opt.label}</Text>
              {reminderLeadMins === opt.value && <Text style={{ color: '#3B82F6', fontSize: 18 }}>✓</Text>}
            </FocusablePressable>
          ))}
        </View>
      </Modal>

      {/* ── Rating picker sheet ── */}
      <Modal
        visible={showRatingSheet}
        transparent
        animationType="slide"
        onShow={() => {
          if (Platform.isTV) setTimeout(() => requestTvFocus(firstRatingOptRef.current), 80);
        }}
        onRequestClose={() => setShowRatingSheet(false)}
      >
        <Pressable
          style={styles.sheetBackdrop}
          onPress={() => setShowRatingSheet(false)}
          focusable={false}
        />
        <View style={[styles.sheet, { backgroundColor: colors.card, paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.sheetHandle} />
          <Text style={[styles.sheetTitle, { color: colors.mutedForeground }]}>CONTENT RATING CEILING</Text>
          {RATING_OPTIONS.map((opt) => (
            <FocusablePressable
              key={opt.value}
              ref={Platform.isTV && opt.value === maxRating ? firstRatingOptRef : undefined}
              style={[styles.sheetRow, { borderBottomColor: colors.border }]}
              onPress={() => handleRatingPress(opt.value)}
            >
              <Text style={[styles.sheetRowText, { color: colors.foreground }]}>{opt.label}</Text>
              {maxRating === opt.value && <Text style={{ color: '#3B82F6', fontSize: 18 }}>✓</Text>}
            </FocusablePressable>
          ))}
        </View>
      </Modal>

      {/* ── PIN entry modal ── */}
      <Modal
        visible={pinFlow !== null}
        transparent={false}
        animationType="slide"
        onRequestClose={() => setPinFlow(null)}
      >
        <PinPad
          mode={isVerifyMode || pinFlow === 'change-pin' ? (pinFlow === 'change-pin' ? 'set' : 'verify') : 'set'}
          title={pinModalTitle()}
          verify={isVerifyMode ? verifyPin : undefined}
          onSuccess={onPinSuccess}
          onCancel={() => { setPinFlow(null); setPendingRating(null); setPendingLock(null); }}
        />
      </Modal>

      {/* ── MAC Restore modal ── */}
      <Modal visible={showMacRestore} transparent animationType="fade" onRequestClose={() => setShowMacRestore(false)}>
        <Pressable style={styles.sheetBackdrop} onPress={() => setShowMacRestore(false)}>
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', paddingHorizontal: 32 }}>
            <Pressable onPress={() => {}}>
              <View style={[{ backgroundColor: colors.card, borderRadius: 20, paddingHorizontal: 24, paddingVertical: 24, width: 340 }]}>
                <Text style={[styles.sheetTitle, { color: colors.mutedForeground, paddingHorizontal: 0, marginBottom: 8 }]}>RESTORE MAC ADDRESS</Text>
                <Text style={{ fontSize: 13, fontFamily: 'Inter_400Regular', color: colors.foreground, marginBottom: 14 }}>
                  Enter your original MAC address (e.g. from your IPTV provider portal).
                </Text>
                <TextInput
                  value={macRestoreInput}
                  onChangeText={(t) => { setMacRestoreInput(t); setMacRestoreError(''); }}
                  placeholder="XX:XX:XX:XX:XX:XX"
                  placeholderTextColor={colors.mutedForeground}
                  autoCapitalize="characters"
                  autoCorrect={false}
                  style={{
                    fontSize: 15,
                    fontFamily: 'Inter_500Medium',
                    letterSpacing: 1,
                    color: colors.foreground,
                    borderWidth: 1,
                    borderColor: colors.border,
                    borderRadius: 8,
                    paddingHorizontal: 12,
                    paddingVertical: 10,
                    marginBottom: 4,
                  }}
                />
                {macRestoreError ? (
                  <Text style={{ fontSize: 12, fontFamily: 'Inter_400Regular', color: '#EF4444', marginVertical: 6 }}>{macRestoreError}</Text>
                ) : (
                  <View style={{ height: 10 }} />
                )}
                <View style={{ flexDirection: 'row', gap: 12, marginTop: 4 }}>
                  <Pressable
                    onPress={() => setShowMacRestore(false)}
                    style={{ flex: 1, paddingVertical: 12, borderRadius: 8, borderWidth: 1, borderColor: colors.border, alignItems: 'center' }}
                  >
                    <Text style={{ fontSize: 14, fontFamily: 'Inter_500Medium', color: colors.foreground }}>Cancel</Text>
                  </Pressable>
                  <Pressable
                    onPress={handleMacRestore}
                    style={{ flex: 1, paddingVertical: 12, borderRadius: 8, backgroundColor: colors.primary ?? '#6366F1', alignItems: 'center' }}
                  >
                    <Text style={{ fontSize: 14, fontFamily: 'Inter_600SemiBold', color: '#FFFFFF' }}>Restore</Text>
                  </Pressable>
                </View>
              </View>
            </Pressable>
          </View>
        </Pressable>
      </Modal>

      {/* ── Community / Telegram modal ── */}
      <CommunityModal visible={showCommunity} onClose={() => setShowCommunity(false)} openerRef={communityRowRef} />

      {/* ── Destructive confirmation dialog (TV-safe: FocusablePressable buttons) ── */}
      {confirmDialog && (
        <ConfirmModal
          visible
          title={confirmDialog.title}
          message={confirmDialog.message}
          confirmLabel={confirmDialog.confirmLabel}
          cancelLabel="Cancel"
          destructive
          openerRef={confirmOpenerRef as React.RefObject<View | null>}
          onConfirm={confirmDialog.onConfirm}
          onCancel={() => setConfirmDialog(null)}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, flexDirection: 'row' },
  left: { flex: 1, borderRightWidth: StyleSheet.hairlineWidth },
  leftContent: { paddingHorizontal: 20, gap: 8 },
  right: { flex: 1 },
  rightContent: { paddingHorizontal: 20, gap: 8 },
  screenTitle: { fontSize: 22, fontFamily: 'Inter_700Bold', letterSpacing: -0.5, marginBottom: 8 },
  sectionLabel: { fontSize: 10, fontFamily: 'Inter_600SemiBold', letterSpacing: 1.5, marginTop: 12, marginBottom: 4 },
  card: { borderRadius: 12, borderWidth: 1, overflow: 'hidden' },
  infoRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 14, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  infoLabel: { fontSize: 13, fontFamily: 'Inter_400Regular' },
  infoValue: { fontSize: 13, fontFamily: 'Inter_500Medium', maxWidth: '65%', textAlign: 'right' },
  macText: { fontSize: 12, fontFamily: 'Inter_500Medium', letterSpacing: 1 },
  typeBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 99 },
  typeBadgeText: { fontSize: 12, fontFamily: 'Inter_600SemiBold' },
  actionRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 14, paddingVertical: 14, gap: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  actionTitle: { fontSize: 14, fontFamily: 'Inter_500Medium' },
  actionSub: { fontSize: 12, fontFamily: 'Inter_400Regular', marginTop: 2 },
  logoutRow: { paddingHorizontal: 14, paddingVertical: 16, alignItems: 'center' },
  logoutText: { fontSize: 15, fontFamily: 'Inter_600SemiBold' },
  // Rating sheet
  sheetBackdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: { borderTopLeftRadius: 20, borderTopRightRadius: 20, paddingTop: 12, paddingHorizontal: 0 },
  sheetHandle: { width: 40, height: 4, borderRadius: 2, backgroundColor: 'rgba(128,128,128,0.4)', alignSelf: 'center', marginBottom: 12 },
  sheetTitle: { fontSize: 10, fontFamily: 'Inter_600SemiBold', letterSpacing: 1.5, paddingHorizontal: 20, paddingBottom: 8 },
  sheetRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 20, paddingVertical: 16, borderBottomWidth: StyleSheet.hairlineWidth },
  sheetRowText: { fontSize: 15, fontFamily: 'Inter_400Regular' },
});
