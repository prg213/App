import React, { useRef, useState } from 'react';
import {
  ActivityIndicator,
  Modal,
  Platform,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { WebView } from 'react-native-webview';
import { FocusablePressable } from '@/components/FocusablePressable';
import { requestTvFocus } from '@/lib/tvFocus';

const TELEGRAM_URL = '';

// Desktop Chrome UA so Telegram's web interface renders properly in the WebView.
const CHROME_UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) ' +
  'AppleWebKit/537.36 (KHTML, like Gecko) ' +
  'Chrome/125.0.0.0 Safari/537.36';

interface Props {
  visible: boolean;
  onClose: () => void;
  /**
   * TV only: ref to the button that opened this modal.  When the modal closes,
   * focus is restored to this element so the D-pad cursor doesn't go dead.
   */
  openerRef?: React.RefObject<View | null>;
}

export function CommunityModal({ visible, onClose, openerRef }: Props) {
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  // TV: close button ref for imperative onShow focus (replaces hasTVPreferredFocus).
  const closeBtnRef = useRef<View>(null);

  // TV: unified close handler — dismisses the modal then returns D-pad focus
  // to whichever button opened it so the cursor doesn't go dead on close.
  const handleClose = React.useCallback(() => {
    onClose();
    if (Platform.isTV && openerRef?.current) {
      setTimeout(() => requestTvFocus(openerRef.current), 150);
    }
  }, [onClose, openerRef]);

  return (
    <Modal
      visible={visible}
      animationType="slide"
      onRequestClose={handleClose}
      statusBarTranslucent
      onShow={() => {
        // TV: focus close button on open — avoids hasTVPreferredFocus races
        // when the loading state changes while the modal is visible.
        if (Platform.isTV) setTimeout(() => requestTvFocus(closeBtnRef.current), 80);
      }}
    >
      <View style={[styles.container, { paddingTop: insets.top }]}>
        {/* ── Header ── */}
        <View style={styles.header}>
          <Text style={styles.title}>💬 Community</Text>
          <FocusablePressable
            ref={closeBtnRef}
            style={styles.closeBtn}
            onPress={handleClose}
            hitSlop={12}
          >
            <Text style={styles.closeTxt}>✕</Text>
          </FocusablePressable>
        </View>

        {TELEGRAM_URL ? (
          <>
            {loading && (
              <View style={styles.loaderOverlay}>
                <ActivityIndicator size="large" color="#3B82F6" />
                <Text style={styles.loaderText}>Opening community…</Text>
              </View>
            )}
            <WebView
              source={{ uri: TELEGRAM_URL }}
              style={styles.webview}
              userAgent={CHROME_UA}
              onLoadEnd={() => setLoading(false)}
              javaScriptEnabled
              domStorageEnabled
            />
          </>
        ) : (
          <View style={styles.empty}>
            <Text style={styles.emptyIcon}>💬</Text>
            <Text style={styles.emptyTitle}>No community channel</Text>
            <Text style={styles.emptyText}>
              A Telegram channel hasn't been set up for your account yet.
            </Text>
          </View>
        )}
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A0A0F',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  title: {
    fontSize: 16,
    fontFamily: 'Inter_600SemiBold',
    color: '#F2F2F2',
  },
  closeBtn: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  closeTxt: {
    fontSize: 14,
    color: '#F2F2F2',
    lineHeight: 18,
  },
  loaderOverlay: {
    position: 'absolute', left: 0, right: 0, bottom: 0,
    top: 56,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
    gap: 14,
  },
  loaderText: {
    fontSize: 14,
    fontFamily: 'Inter_400Regular',
    color: 'rgba(255,255,255,0.5)',
  },
  webview: {
    flex: 1,
    backgroundColor: '#0A0A0F',
  },
  empty: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 40, gap: 12 },
  emptyIcon: { fontSize: 48, textAlign: 'center' },
  emptyTitle: { fontSize: 18, fontFamily: 'Inter_600SemiBold', color: '#F2F2F2', textAlign: 'center' },
  emptyText: { fontSize: 13, fontFamily: 'Inter_400Regular', color: 'rgba(255,255,255,0.5)', textAlign: 'center', lineHeight: 20 },
});
