/**
 * Task #259 — CatchupSheet D-pad focus order on Firestick
 *
 * Future programme rows are non-focusable (`focusable={canPlay}`) so that
 * D-pad navigation on the Firestick skips them cleanly.  This test suite
 * inspects the source to confirm:
 *
 *   1. Every programme row passes `focusable={canPlay}` to FocusablePressable
 *      so future rows are excluded from the TV focus chain.
 *   2. `canPlay` is defined as `isPast || isCurrent` — the currently-airing
 *      (NOW) programme is always playable and therefore always focusable.
 *   3. The close button carries `hasTVPreferredFocus` so focus lands on it
 *      (not in a void) when D-pad reaches the end of the list.
 *   4. The `isCurrent` flag is derived from the programme's start/end window
 *      straddling `nowTs`, guaranteeing that the NOW row is never omitted from
 *      the focus chain due to an off-by-one on the boundary condition.
 *
 * Why source inspection instead of a render test?
 * ─────────────────────────────────────────────────
 * React Native TV focus (hasTVPreferredFocus, focusable) is resolved by the
 * native layer on an actual device or Apple/Fire TV emulator — jsdom/node
 * cannot simulate it.  Inspecting the source guarantees the correct props are
 * authored and that no refactor accidentally drops them.
 */

import * as fs from 'fs';
import * as path from 'path';

// ── Load the production source once ──────────────────────────────────────────

const SOURCE_PATH = path.join(
  __dirname,
  '../components/CatchupSheet.tsx',
);

let src: string;

beforeAll(() => {
  src = fs.readFileSync(SOURCE_PATH, 'utf8');
});

// ─────────────────────────────────────────────────────────────────────────────
// 1. focusable prop — future rows must be excluded from the TV focus chain
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — programme row focusability (#259)', () => {
  it('passes focusable={canPlay} to FocusablePressable so future rows are non-focusable', () => {
    // The render loop must set `focusable` equal to `canPlay`.
    // Acceptable spellings: `focusable={canPlay}` or `focusable = {canPlay}`.
    expect(src).toMatch(/focusable=\{canPlay\}/);
  });

  it('does NOT hard-code focusable={true} on programme rows (would re-enable future rows)', () => {
    // If someone changed it to always-true the future-skip would break.
    // The only acceptable hard-coded true is on non-programme UI (e.g. day pills,
    // close button), so we check the programme-list section specifically by
    // confirming `focusable={true}` does not appear immediately before a
    // progRow-related style reference.
    //
    // Simpler guard: the file must NOT contain `focusable={true}` at all — day
    // pills and the close button rely on the default (omitting the prop means
    // focusable by default), not an explicit `true`.
    expect(src).not.toMatch(/focusable=\{true\}/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 2. canPlay definition — NOW row must always be focusable
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — canPlay includes isCurrent (#259)', () => {
  it('defines canPlay as isPast || isCurrent so the NOW row is always playable', () => {
    // Matches: const canPlay = isPast || isCurrent;
    expect(src).toMatch(/canPlay\s*=\s*isPast\s*\|\|\s*isCurrent/);
  });

  it('defines isCurrent using start <= nowTs < end (boundary-inclusive on start)', () => {
    // The NOW window must include the exact start moment so a programme that
    // just started is immediately focusable.
    // Matches: prog.start.getTime() <= nowTs && nowTs < prog.end.getTime()
    expect(src).toMatch(/prog\.start\.getTime\(\)\s*<=\s*nowTs/);
    expect(src).toMatch(/nowTs\s*<\s*prog\.end\.getTime\(\)/);
  });

  it('defines isPast using prog.end < nowTs so finished programmes remain playable', () => {
    // Matches: prog.end.getTime() < nowTs
    expect(src).toMatch(/prog\.end\.getTime\(\)\s*<\s*nowTs/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 3. hasTVPreferredFocus on close button — focus lands somewhere after list ends
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — close button TV focus (#259)', () => {
  it('sets hasTVPreferredFocus on the close button so focus is not lost after skipping future rows', () => {
    // When D-pad passes the last playable row and all remaining rows are Future,
    // the TV focus engine looks for hasTVPreferredFocus to decide where to jump.
    // The close button is the designated landing target.
    expect(src).toMatch(/hasTVPreferredFocus/);
  });

  it('the close button carries closeBtnRef so focus can be moved to it programmatically as the TV fallback', () => {
    // The close button FocusablePressable must have ref={closeBtnRef} so the
    // onShow / day-change callbacks can call .focus() on it when there are no
    // playable rows to land on — preventing D-pad focus from being lost.
    const closeFpIdx = src.indexOf('ref={closeBtnRef}');
    expect(closeFpIdx).toBeGreaterThan(-1);
    // Confirm the ref sits on the close-button element (✕ or closeTouchable
    // within 500 chars of the ref prop).
    const win = src.slice(Math.max(0, closeFpIdx - 100), closeFpIdx + 500);
    expect(win).toMatch(/onClose|closeTouchable|closeIcon|✕/);
    // Confirm requestTvFocus is called with closeBtnRef.current so focus
    // routing uses the forced-focus helper (reliable on Fire OS).
    expect(src).toMatch(/requestTvFocus\(\s*closeBtnRef\.current/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 4. nowTs — stable snapshot so focus classification doesn't shift mid-render
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — nowTs is a stable snapshot (#259)', () => {
  it('keeps nowTs in state (not a render-body Date.now() call) so memos do not recompute every frame', () => {
    // nowTs must come from useState so that firstPlayableIndex / lastPlayableIndex
    // memos are stable between renders.  A bare `Date.now()` in render would
    // change every millisecond, defeating useMemo caching and producing new
    // inline ref-callback closures on every render — the root cause of the
    // "Maximum update depth exceeded" crash when the catchup sheet mounts.
    expect(src).toMatch(/useState\s*\(\s*Date\.now\s*\)/);
    // The interval that refreshes it must also be present.
    expect(src).toMatch(/setInterval\s*\(\s*\(\s*\)\s*=>\s*setNowTs\s*\(\s*Date\.now\s*\(\s*\)\s*\)/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 5. nextFocusDown anti-wrap guard (#270)
//    The last playable row must wire nextFocusDown to the first day-strip pill
//    so D-pad Down never wraps back to the close button or first row.
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — nextFocusDown anti-wrap guard (#270)', () => {
  it('computes lastPlayableIndex to identify which programme row gets the nextFocusDown wire', () => {
    // The variable must exist; it drives the ref callback on the last row.
    expect(src).toMatch(/lastPlayableIndex/);
  });

  it('creates a firstDayPillRef to serve as the nextFocusDown target', () => {
    // The ref must be created so the day-strip pill can receive focus after
    // the last programme row on D-pad Down.
    expect(src).toMatch(/firstDayPillRef/);
  });

  it('attaches firstDayPillRef to the first day-strip pill (i === 0)', () => {
    // Matches: `if (i === 0) { ... firstDayPillRef ... }` or inline ternary.
    // Uses [\s\S] instead of . so the check spans across newlines.
    expect(src).toMatch(/i\s*===\s*0[\s\S]{0,80}firstDayPillRef|firstDayPillRef[\s\S]{0,80}i\s*===\s*0/);
  });

  it('uses setNativeProps with nextFocusDown on the last playable row to prevent wrap', () => {
    // The setNativeProps call that sets nextFocusDown is the mechanism that
    // stops D-pad Down from cycling back to the header.
    expect(src).toMatch(/setNativeProps\(\s*\{\s*nextFocusDown/);
  });

  it('derives the nextFocusDown handle from findNodeHandle so Fire OS gets a valid node reference', () => {
    // findNodeHandle converts the React ref to a native integer handle —
    // required on Android TV / Fire OS where refs are not accepted directly.
    expect(src).toMatch(/findNodeHandle\(firstDayPillRef/);
  });
});

// ─────────────────────────────────────────────────────────────────────────────
// 6. Day-switch focus (#282)
//    When the user picks a different day in the strip, focus must move to the
//    first playable programme row for that day (or back to the day strip if
//    there are no playable rows), rather than staying on the close button or
//    being lost entirely.
// ─────────────────────────────────────────────────────────────────────────────

describe('CatchupSheet — day-switch focus (#282)', () => {
  it('creates a firstPlayableRowRef to hold the first playable programme row', () => {
    // The ref is assigned inside the render loop and consumed by the
    // day-change effect to programmatically route focus.
    expect(src).toMatch(/firstPlayableRowRef/);
  });

  it('creates a dayChangedRef to skip the initial mount in the day-change effect', () => {
    // On the first render hasTVPreferredFocus handles initial focus placement.
    // dayChangedRef guards against the effect also firing at mount and
    // double-moving focus away from the natural initial landing spot.
    expect(src).toMatch(/dayChangedRef/);
  });

  it('calls requestTvFocus on firstPlayableRowRef in the day-change effect to move TV focus', () => {
    // After selectedDay changes, the effect programmatically moves focus by
    // calling requestTvFocus(firstPlayableRowRef.current) — the forced-focus
    // helper that toggles hasTVPreferredFocus on Fire OS for reliable D-pad
    // cursor placement.
    expect(src).toMatch(/requestTvFocus\(\s*firstPlayableRowRef\.current/);
  });

  it('falls back to firstDayPillRef when there are no playable rows for the new day', () => {
    // When data hasn't loaded yet, the timeout branch checks
    // `focusPlacedOnDayPillRef.current` and, if true, routes focus to
    // firstDayPillRef so the user can pick another day.
    // The check and the target appear within the same else-if block
    // (allow up to 300 chars to accommodate comments between them).
    expect(src).toMatch(
      /focusPlacedOnDayPillRef\.current\)\s*\{[\s\S]{0,300}firstDayPillRef/,
    );
  });

  it('triggers the day-change effect when selectedDay changes', () => {
    // The useEffect dependency array must include selectedDay so the effect
    // re-runs every time the user picks a new day from the strip.
    expect(src).toMatch(/\[\s*selectedDay\s*\]/);
  });

  it('assigns firstPlayableRowRef only to the row at firstPlayableIndex', () => {
    // The ref callback in the render loop must check i === firstPlayableIndex
    // before storing the ref so that later rows do not overwrite it.
    expect(src).toMatch(/i\s*===\s*firstPlayableIndex[\s\S]{0,120}firstPlayableRowRef|firstPlayableRowRef[\s\S]{0,120}i\s*===\s*firstPlayableIndex/);
  });

  it('focuses the first playable row in the onShow handler so focus lands correctly on initial open', () => {
    // On first open the Modal.onShow callback calls .focus() on
    // firstPlayableRowRef.current (or falls back to closeBtnRef) so TV focus
    // lands on the first playable row without requiring hasTVPreferredFocus props.
    // This is more reliable than a static prop because onShow fires after the
    // native modal animation completes and all nodes are mounted.
    expect(src).toMatch(/onShow[\s\S]{0,400}firstPlayableRowRef/);
  });

  it('uses a setTimeout delay in the day-change effect to let the list re-render before focusing', () => {
    // Without a short delay the new programme rows may not yet be mounted,
    // so focus would target a stale or unmounted node.
    // The effect must schedule requestTvFocus via setTimeout (any positive delay).
    expect(src).toMatch(/setTimeout[\s\S]{0,200}requestTvFocus/);
  });

  it('sets focusPlacedOnDayPillRef when falling back to the day pill due to loading', () => {
    // The flag lets the data-arrival effect know it should re-route focus
    // once the programme list populates.
    expect(src).toMatch(/focusPlacedOnDayPillRef/);
  });

  it('has a [firstPlayableIndex] effect that re-routes focus when data arrives after loading', () => {
    // The second effect triggers when firstPlayableIndex changes from -1 to a
    // valid value, completing the two-step slow-load focus journey.
    expect(src).toMatch(/\[\s*firstPlayableIndex\s*\]/);
  });

  it('the data-arrival effect guards on focusPlacedOnDayPillRef before moving focus', () => {
    // Without the guard the effect would re-route focus on every re-render
    // where firstPlayableIndex changes, even when the user hasn't switched days.
    expect(src).toMatch(/focusPlacedOnDayPillRef\.current.*return|return.*focusPlacedOnDayPillRef\.current/);
  });
});
