# StreamVault current Live TV/VLC source bundle

This archive was assembled from the current checkout on 2026-08-24 after the latest Android build.
Project revision: 7814f5a43aad6901191bbe8bb600ef41bc3c6d62
Project revision subject: Add fullscreen fill fix asset for StreamVault LiveTV VLC mini player

The project source was not edited while preparing this archive. The bundle includes the React Native
Live TV/player paths, Android VLC/libVLC integration and custom patch, persistent mini/fullscreen
surface handoff, layout/measurement/aspect-ratio logic, player lifecycle, channel selection/switching,
relevant tests, and Android/Expo build support.

## Included

- Live TV tab, fullscreen player route, root/tab layout handoff configuration
- NativeStreamPlayer Android and non-Android implementations
- TVLiveLayout, channel menu/card, focus and remote helpers
- LivePlayerContext, app state, storage, EPG/M3U/Xtream services and supporting types/utilities
- Selected Live TV/VLC/channel/audio/fullscreen regression tests and their shared test mocks
- Expo/native plugins, Gradle project files, Android activity/application/manifest, wrapper, and package lockfiles
- patches/react-native-vlc-media-player@1.0.98.patch

## Excluded

- node_modules and package-manager caches
- .expo state, Gradle caches, generated Android build/output folders, reports, and APKs
- debug/release signing keystores and other signing material
- eas.json because its current copy contains an API-key value
- .env files, credentials, tokens, private keys, and secrets
- unrelated screens/components/tests and unnecessary generated Android resources
