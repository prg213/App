# StreamVault current Android Live TV/VLC source bundle

This bundle was assembled from the current project checkout without editing project source files.
It contains the persistent Android Live TV VLC player, mini/fullscreen presentation paths,
transition state, channel selection/switching, player lifecycle, sizing logic, custom VLC patch,
relevant tests, and the Android/Expo build configuration needed to reproduce the native changes.

## Current-state notes

- The Android path uses the existing single persistent VLC player/native surface architecture.
- The current fullscreen sizing rule is in `artifacts/iptv-app/components/TVLiveLayout.tsx`.
- The custom native `react-native-vlc-media-player` integration is represented by
  `patches/react-native-vlc-media-player@1.0.98.patch`; `node_modules` is intentionally excluded.
- `artifacts/iptv-app/eas.json` is intentionally excluded because its current copy contains an
  `EXPO_PUBLIC_TMDB_API_KEY` value. Recreate build-time environment values through secrets/configuration,
  not by copying credentials into source.
- `android/app/build.gradle` contains the stock Android debug signing literals required by the generated
  Gradle configuration, but the corresponding `debug.keystore` and all release signing material are excluded.
  Those stock literals are not project release credentials.

## Excluded

`node_modules`, caches, `.expo` state, Gradle/build output, APKs, signing/release keys, `.env` files,
EAS config containing an API key, and unrelated generated Android resources.
