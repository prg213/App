import * as SecureStore from 'expo-secure-store';
import AsyncStorage from '@react-native-async-storage/async-storage';
import type { Credentials, FavoriteChannel, FavoriteMovie, FavoriteSeries, ParentalSettings, RecentChannel, Reminder, WatchHistoryEntry } from '@/types';

// Credentials live in SecureStore (Android Keystore / iOS Keychain).
// This survives Expo Go bundle reloads and Metro restarts — unlike AsyncStorage
// which can be wiped when Expo Go establishes a new development connection.
const SECURE_CREDS_KEY = 'sv_credentials';
// PIN also lives in SecureStore — never in AsyncStorage so it cannot be
// read without the device being unlocked (Android Keystore / iOS Keychain).
const SECURE_PIN_KEY = 'sv_pin';

// Everything else (favourites, history, cache) stays in AsyncStorage.
// Exported so tests can iterate the full key list and catch any key added to
// KEYS that is missing from clearCredentials.
export const KEYS = {
  FAVORITES: 'sv_favorites',
  MOVIE_FAVORITES: 'sv_movie_favorites',
  SERIES_FAVORITES: 'sv_series_favorites',
  HISTORY: 'sv_history',
  CHANNELS_CACHE: 'sv_channels_cache',
  MOVIES_CACHE: 'sv_movies_cache',
  PARENTAL: 'sv_parental',
  RECENT_CHANNELS: 'sv_recent_channels',
  REMINDERS: 'sv_reminders',
  PREF_AUDIO_LANG: 'sv_pref_audio_lang',
  PREF_SUBTITLE_LANG: 'sv_pref_subtitle_lang',
  PREF_REMINDER_LEAD_MINS: 'sv_pref_reminder_lead_mins',
  PREF_SEARCH_TYPE: 'sv_pref_search_type',
  PREF_SEARCH_QUERY: 'sv_pref_search_query',
  BACKFILL_TS: 'sv_backfill_ts',
  RECENT_SEARCHES: 'sv_recent_searches',
  // Written just before a forced logout so the activation screen can show
  // a one-time explanation banner. Intentionally NOT cleared in clearCredentials
  // so it survives the logout and is readable on first render of activation.
  LOGOUT_REASON: 'sv_logout_reason',
  // #267: persisted consecutive MAC-check failure count so force-quitting and
  // relaunching cannot indefinitely reset the deactivation streak to 0.
  STARTUP_FAIL_COUNT: 'sv_startup_fail_count',
  // #21: pending remote-fav push payloads that survived an app restart.
  // Cleared on logout (they are tied to the previous device MAC).
  PENDING_PUSH_MOVIES: 'sv_pending_push_movies',
  PENDING_PUSH_SERIES: 'sv_pending_push_series',
};

// Device-scoped UI preferences — intentionally NOT cleared on logout so the
// app feels familiar on re-login (sort order, last category, playback speed).
// Kept separate from KEYS so clearCredentials.test.ts does not require them
// to be wiped; they are verified by their own typed wrappers in StorageService.
// Uses @pref_* namespace (not sv_*) to make the non-user-data intent obvious.
export const DEVICE_PREF_KEYS = {
  PREF_MOVIE_SORT: '@pref_movie_sort',
  PREF_SERIES_SORT: '@pref_series_sort',
  PREF_LIVE_CAT: '@pref_live_cat',
  PREF_PLAYBACK_SPEED: '@pref_playback_speed',
};

export const StorageService = {
  // ── Credentials (SecureStore) ──────────────────────────────────────────────

  async saveCredentials(creds: Credentials): Promise<void> {
    await SecureStore.setItemAsync(SECURE_CREDS_KEY, JSON.stringify(creds));
  },

  async getCredentials(): Promise<Credentials | null> {
    try {
      const data = await SecureStore.getItemAsync(SECURE_CREDS_KEY);
      return data ? (JSON.parse(data) as Credentials) : null;
    } catch {
      return null;
    }
  },

  async clearCredentials(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync(SECURE_CREDS_KEY);
    } catch {
      // ignore if key doesn't exist
    }
    await AsyncStorage.multiRemove([
      KEYS.FAVORITES,
      KEYS.MOVIE_FAVORITES,
      KEYS.SERIES_FAVORITES,
      KEYS.HISTORY,
      KEYS.CHANNELS_CACHE,
      KEYS.MOVIES_CACHE,
      KEYS.PARENTAL,
      KEYS.RECENT_CHANNELS,
      KEYS.REMINDERS,
      KEYS.PREF_AUDIO_LANG,
      KEYS.PREF_SUBTITLE_LANG,
      KEYS.PREF_REMINDER_LEAD_MINS,
      KEYS.PREF_SEARCH_TYPE,
      KEYS.PREF_SEARCH_QUERY, // #122: clear saved search query on logout
      KEYS.BACKFILL_TS,
      KEYS.RECENT_SEARCHES,  // #122: also clear recent search history on logout
      KEYS.STARTUP_FAIL_COUNT,     // #267: reset persisted failure streak on logout
      KEYS.PENDING_PUSH_MOVIES,    // #21: pending push tied to previous MAC
      KEYS.PENDING_PUSH_SERIES,    // #21
      // NOTE: LOGOUT_REASON is intentionally excluded — it must survive logout
      // so the activation screen can display a one-time explanation banner.
    ]);
  },

  // ── PIN (SecureStore) ──────────────────────────────────────────────────────

  async setPin(pin: string): Promise<void> {
    await SecureStore.setItemAsync(SECURE_PIN_KEY, pin);
  },

  async getPin(): Promise<string | null> {
    try {
      return await SecureStore.getItemAsync(SECURE_PIN_KEY);
    } catch {
      return null;
    }
  },

  async clearPin(): Promise<void> {
    try {
      await SecureStore.deleteItemAsync(SECURE_PIN_KEY);
    } catch {}
  },

  async verifyPin(pin: string): Promise<boolean> {
    const stored = await StorageService.getPin();
    return stored !== null && stored === pin;
  },

  // ── Parental settings (AsyncStorage) ──────────────────────────────────────

  async getParentalSettings(): Promise<ParentalSettings> {
    try {
      const data = await AsyncStorage.getItem(KEYS.PARENTAL);
      // Spread existing data over defaults so old stored data without blockedChannels
      // still gets a valid empty array rather than undefined.
      if (data) {
        const s = JSON.parse(data) as ParentalSettings;
        return { blockedCategories: [], ...s, blockedChannels: s.blockedChannels ?? [] };
      }
      return { maxRating: 'all', lockEnabled: false, blockedChannels: [], blockedCategories: [] };
    } catch {
      return { maxRating: 'all', lockEnabled: false, blockedChannels: [], blockedCategories: [] };
    }
  },

  async saveParentalSettings(settings: ParentalSettings): Promise<void> {
    await AsyncStorage.setItem(KEYS.PARENTAL, JSON.stringify(settings));
  },

  // ── Channel Favourites (AsyncStorage) ─────────────────────────────────────

  async getFavorites(): Promise<FavoriteChannel[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.FAVORITES);
      return data ? (JSON.parse(data) as FavoriteChannel[]) : [];
    } catch {
      return [];
    }
  },
  async saveFavorites(favorites: FavoriteChannel[]): Promise<void> {
    await AsyncStorage.setItem(KEYS.FAVORITES, JSON.stringify(favorites));
  },
  async toggleFavorite(channel: FavoriteChannel): Promise<FavoriteChannel[]> {
    const current = await StorageService.getFavorites();
    const exists = current.find((f) => f.id === channel.id);
    const updated = exists
      ? current.filter((f) => f.id !== channel.id)
      : [channel, ...current];
    await StorageService.saveFavorites(updated);
    return updated;
  },

  // ── Movie Favourites (AsyncStorage) ───────────────────────────────────────

  async getMovieFavorites(): Promise<FavoriteMovie[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.MOVIE_FAVORITES);
      return data ? (JSON.parse(data) as FavoriteMovie[]) : [];
    } catch {
      return [];
    }
  },
  async saveMovieFavorites(favorites: FavoriteMovie[]): Promise<void> {
    await AsyncStorage.setItem(KEYS.MOVIE_FAVORITES, JSON.stringify(favorites));
  },
  async toggleMovieFavorite(movie: FavoriteMovie): Promise<FavoriteMovie[]> {
    const current = await StorageService.getMovieFavorites();
    const exists = current.find((f) => f.id === movie.id);
    const updated = exists ? current.filter((f) => f.id !== movie.id) : [movie, ...current];
    await AsyncStorage.setItem(KEYS.MOVIE_FAVORITES, JSON.stringify(updated));
    return updated;
  },
  async moveMovieToTop(id: string): Promise<FavoriteMovie[] | null> {
    const current = await StorageService.getMovieFavorites();
    const idx = current.findIndex((f) => f.id === id);
    if (idx <= 0) return null; // already at top or not found
    const item = current[idx];
    const updated = [item, ...current.slice(0, idx), ...current.slice(idx + 1)];
    await AsyncStorage.setItem(KEYS.MOVIE_FAVORITES, JSON.stringify(updated));
    return updated;
  },

  async moveSeriesToTop(id: string): Promise<FavoriteSeries[] | null> {
    const current = await StorageService.getSeriesFavorites();
    const idx = current.findIndex((f) => f.id === id);
    if (idx <= 0) return null;
    const item = current[idx];
    const updated = [item, ...current.slice(0, idx), ...current.slice(idx + 1)];
    await AsyncStorage.setItem(KEYS.SERIES_FAVORITES, JSON.stringify(updated));
    return updated;
  },

  // ── Pending remote-fav push queue (#21) ──────────────────────────────────
  //
  // Persists a failed remote-push payload across app restarts so the next
  // successful startup can retry the push without losing the queued data.
  // Both keys are cleared in clearCredentials because the payload is tied to
  // the device MAC of the previous session.

  async getPendingMoviesPush(): Promise<FavoriteMovie[] | null> {
    try {
      const data = await AsyncStorage.getItem(KEYS.PENDING_PUSH_MOVIES);
      return data ? (JSON.parse(data) as FavoriteMovie[]) : null;
    } catch { return null; }
  },
  async setPendingMoviesPush(items: FavoriteMovie[] | null): Promise<void> {
    if (items === null) {
      await AsyncStorage.removeItem(KEYS.PENDING_PUSH_MOVIES);
    } else {
      await AsyncStorage.setItem(KEYS.PENDING_PUSH_MOVIES, JSON.stringify(items));
    }
  },

  async getPendingSeriesPush(): Promise<FavoriteSeries[] | null> {
    try {
      const data = await AsyncStorage.getItem(KEYS.PENDING_PUSH_SERIES);
      return data ? (JSON.parse(data) as FavoriteSeries[]) : null;
    } catch { return null; }
  },
  async setPendingSeriesPush(items: FavoriteSeries[] | null): Promise<void> {
    if (items === null) {
      await AsyncStorage.removeItem(KEYS.PENDING_PUSH_SERIES);
    } else {
      await AsyncStorage.setItem(KEYS.PENDING_PUSH_SERIES, JSON.stringify(items));
    }
  },

  // ── Series Favourites (AsyncStorage) ──────────────────────────────────────

  async getSeriesFavorites(): Promise<FavoriteSeries[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.SERIES_FAVORITES);
      return data ? (JSON.parse(data) as FavoriteSeries[]) : [];
    } catch {
      return [];
    }
  },
  async saveSeriesFavorites(favorites: FavoriteSeries[]): Promise<void> {
    await AsyncStorage.setItem(KEYS.SERIES_FAVORITES, JSON.stringify(favorites));
  },
  async toggleSeriesFavorite(series: FavoriteSeries): Promise<FavoriteSeries[]> {
    const current = await StorageService.getSeriesFavorites();
    const exists = current.find((f) => f.id === series.id);
    const updated = exists ? current.filter((f) => f.id !== series.id) : [series, ...current];
    await AsyncStorage.setItem(KEYS.SERIES_FAVORITES, JSON.stringify(updated));
    return updated;
  },

  // ── Watch history (AsyncStorage) ──────────────────────────────────────────

  async getWatchHistory(): Promise<WatchHistoryEntry[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.HISTORY);
      return data ? (JSON.parse(data) as WatchHistoryEntry[]) : [];
    } catch {
      return [];
    }
  },
  async addToHistory(entry: WatchHistoryEntry): Promise<void> {
    const history = await StorageService.getWatchHistory();
    const filtered = history.filter((h) => h.id !== entry.id);
    const updated = [entry, ...filtered].slice(0, 100);
    await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify(updated));
  },

  async removeFromHistory(id: string): Promise<void> {
    const history = await StorageService.getWatchHistory();
    const updated = history.filter((h) => h.id !== id);
    await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify(updated));
  },

  /**
   * Removes all history entries that belong to a given series (matched by
   * parentId OR id).  Use this instead of removeFromHistory when removing a
   * series from the Recently Watched grid, because individual episode entries
   * are stored with their own id and a separate parentId pointing to the series.
   */
  async removeSeriesFromHistory(seriesId: string): Promise<void> {
    const history = await StorageService.getWatchHistory();
    const updated = history.filter(
      (h) => h.parentId !== seriesId && h.id !== seriesId,
    );
    await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify(updated));
  },

  async clearHistory(): Promise<void> {
    await AsyncStorage.setItem(KEYS.HISTORY, JSON.stringify([]));
  },

  // ── Recently watched channels (AsyncStorage) ───────────────────────────────

  async getRecentChannels(): Promise<RecentChannel[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.RECENT_CHANNELS);
      if (!data) return [];
      const parsed = JSON.parse(data) as RecentChannel[];
      // Silently trim legacy lists that exceeded the 10-entry cap.
      if (parsed.length > 10) {
        const trimmed = parsed.slice(0, 10);
        await AsyncStorage.setItem(KEYS.RECENT_CHANNELS, JSON.stringify(trimmed));
        return trimmed;
      }
      return parsed;
    } catch {
      return [];
    }
  },

  /**
   * Adds (or moves to the top) a channel in the recently-watched list.
   * Deduplicates by channel ID and retains at most 20 entries.
   */
  async addRecentChannel(ch: RecentChannel): Promise<void> {
    const current = await StorageService.getRecentChannels();
    const deduped = current.filter((c) => c.id !== ch.id);
    const updated = [{ ...ch, watchedAt: Date.now() }, ...deduped].slice(0, 10);
    await AsyncStorage.setItem(KEYS.RECENT_CHANNELS, JSON.stringify(updated));
  },

  /** Remove a single channel from the recently-watched list by ID. */
  async removeFromRecentChannels(id: string): Promise<void> {
    const current = await StorageService.getRecentChannels();
    const updated = current.filter((c) => c.id !== id);
    await AsyncStorage.setItem(KEYS.RECENT_CHANNELS, JSON.stringify(updated));
  },

  // ── Reminders (AsyncStorage) ──────────────────────────────────────────────

  async getReminders(): Promise<Reminder[]> {
    try {
      const data = await AsyncStorage.getItem(KEYS.REMINDERS);
      return data ? (JSON.parse(data) as Reminder[]) : [];
    } catch { return []; }
  },

  async addReminder(reminder: Reminder): Promise<void> {
    const current = await StorageService.getReminders();
    const deduped = current.filter((r) => r.id !== reminder.id);
    await AsyncStorage.setItem(KEYS.REMINDERS, JSON.stringify([reminder, ...deduped]));
  },

  /**
   * Atomically replaces the entire reminders list in storage.
   * Use this when updating multiple reminders at once to avoid read-modify-write races.
   */
  async saveReminders(reminders: Reminder[]): Promise<void> {
    await AsyncStorage.setItem(KEYS.REMINDERS, JSON.stringify(reminders));
  },

  async removeReminder(id: string): Promise<void> {
    const current = await StorageService.getReminders();
    await AsyncStorage.setItem(KEYS.REMINDERS, JSON.stringify(current.filter((r) => r.id !== id)));
  },

  /**
   * Partially updates a stored reminder by merging the given patch into the
   * existing entry.  No-ops silently if the id is not found.
   */
  async updateReminder(id: string, patch: Partial<Reminder>): Promise<void> {
    const current = await StorageService.getReminders();
    const updated = current.map((r) => (r.id === id ? { ...r, ...patch } : r));
    await AsyncStorage.setItem(KEYS.REMINDERS, JSON.stringify(updated));
  },

  async hasReminder(id: string): Promise<boolean> {
    const current = await StorageService.getReminders();
    return current.some((r) => r.id === id);
  },

  /**
   * #95/#101: Remove reminders whose programme ended more than `maxAgeMins`
   * minutes ago (default 24 h).  Returns the titles of every removed reminder
   * so the caller can notify the user if anything was pruned.
   */
  async pruneExpiredReminders(maxAgeMins = 24 * 60): Promise<string[]> {
    try {
      const current = await StorageService.getReminders();
      const cutoff = Date.now() - maxAgeMins * 60 * 1000;
      const kept = current.filter((r) => new Date(r.end).getTime() > cutoff);
      const removed = current.filter((r) => new Date(r.end).getTime() <= cutoff);
      if (removed.length > 0) {
        await AsyncStorage.setItem(KEYS.REMINDERS, JSON.stringify(kept));
      }
      return removed.map((r) => r.programTitle ?? r.channelName ?? 'Unknown');
    } catch {
      return [];
    }
  },

  /** Returns the notificationId stored for the given reminder, or null. */
  async getReminderNotificationId(id: string): Promise<string | null> {
    const current = await StorageService.getReminders();
    return current.find((r) => r.id === id)?.notificationId ?? null;
  },

  // ── Preferred audio language (AsyncStorage) ────────────────────────────────

  /**
   * Returns the stored preferred audio language code (e.g. "en", "ar") or
   * null if no preference has been set.
   */
  async getPrefAudioLanguage(): Promise<string | null> {
    try {
      return await AsyncStorage.getItem(KEYS.PREF_AUDIO_LANG);
    } catch {
      return null;
    }
  },

  /** Persists the user's preferred audio language code. */
  async setPrefAudioLanguage(lang: string): Promise<void> {
    await AsyncStorage.setItem(KEYS.PREF_AUDIO_LANG, lang);
  },

  /** Clears the preferred audio language so the stream default is used. */
  async clearPrefAudioLanguage(): Promise<void> {
    try {
      await AsyncStorage.removeItem(KEYS.PREF_AUDIO_LANG);
    } catch {}
  },

  // ── Clear recently-watched channels ───────────────────────────────────────
  async clearRecentChannels(): Promise<void> {
    await AsyncStorage.setItem(KEYS.RECENT_CHANNELS, JSON.stringify([]));
  },

  // ── Preferred subtitle language (AsyncStorage) ────────────────────────────
  async getPrefSubtitleLang(): Promise<string | null> {
    try { return await AsyncStorage.getItem(KEYS.PREF_SUBTITLE_LANG); } catch { return null; }
  },
  async setPrefSubtitleLang(lang: string): Promise<void> {
    await AsyncStorage.setItem(KEYS.PREF_SUBTITLE_LANG, lang);
  },
  async clearPrefSubtitleLang(): Promise<void> {
    try { await AsyncStorage.removeItem(KEYS.PREF_SUBTITLE_LANG); } catch {}
  },

  // ── Reminder lead time preference (AsyncStorage) ───────────────────────────

  /**
   * Returns the stored reminder lead time in minutes (5, 10, or 15).
   * Defaults to 5 if no preference has been saved yet.
   */
  async getReminderLeadMins(): Promise<number> {
    try {
      const val = await AsyncStorage.getItem(KEYS.PREF_REMINDER_LEAD_MINS);
      if (val) {
        const n = parseInt(val, 10);
        if ([5, 10, 15].includes(n)) return n;
      }
    } catch {}
    return 5;
  },

  /** Persists the user's chosen reminder lead time (5, 10, or 15 minutes). */
  async setReminderLeadMins(mins: 5 | 10 | 15): Promise<void> {
    await AsyncStorage.setItem(KEYS.PREF_REMINDER_LEAD_MINS, String(mins));
  },

  // ── Preferred search type (AsyncStorage) ──────────────────────────────────

  /**
   * Returns the last-used search filter ('all' | 'live' | 'movies' | 'series').
   * Defaults to 'all' if no preference has been saved yet.
   */
  async getPrefSearchType(): Promise<'all' | 'live' | 'movies' | 'series'> {
    try {
      const val = await AsyncStorage.getItem(KEYS.PREF_SEARCH_TYPE);
      if (val === 'all' || val === 'live' || val === 'movies' || val === 'series') return val;
    } catch {}
    return 'all';
  },

  /** Persists the user's chosen search filter type. */
  async setPrefSearchType(type: 'all' | 'live' | 'movies' | 'series'): Promise<void> {
    await AsyncStorage.setItem(KEYS.PREF_SEARCH_TYPE, type);
  },

  // ── Preferred search query (AsyncStorage) ─────────────────────────────────

  /** Returns the last search query the user typed, or empty string. */
  async getPrefSearchQuery(): Promise<string> {
    try {
      return (await AsyncStorage.getItem(KEYS.PREF_SEARCH_QUERY)) ?? '';
    } catch { return ''; }
  },

  /** Persists the search query; clears the key when query is empty. */
  async setPrefSearchQuery(q: string): Promise<void> {
    try {
      if (q) {
        await AsyncStorage.setItem(KEYS.PREF_SEARCH_QUERY, q);
      } else {
        await AsyncStorage.removeItem(KEYS.PREF_SEARCH_QUERY);
      }
    } catch {}
  },

  // ── Logout reason (AsyncStorage) ──────────────────────────────────────────

  /** Persists the reason for a forced logout so the activation screen can show
   *  a one-time explanation. Call before clearing credentials. */
  // ── Persisted MAC failure count (#267) ────────────────────────────────────
  // Survives force-quits so repeated cold-starts cannot reset the deactivation
  // streak.  All three helpers are fire-and-forget safe (callers may void them).

  async getStartupFailCount(): Promise<number> {
    try {
      const raw = await AsyncStorage.getItem(KEYS.STARTUP_FAIL_COUNT);
      if (!raw) return 0;
      const n = parseInt(raw, 10);
      return Number.isFinite(n) && n > 0 ? n : 0;
    } catch { return 0; }
  },

  async saveStartupFailCount(count: number): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.STARTUP_FAIL_COUNT, String(count));
    } catch { /* ignore — in-memory counter still works */ }
  },

  async clearStartupFailCount(): Promise<void> {
    try {
      await AsyncStorage.removeItem(KEYS.STARTUP_FAIL_COUNT);
    } catch { /* ignore */ }
  },

  async saveLogoutReason(reason: string): Promise<void> {
    try {
      await AsyncStorage.setItem(KEYS.LOGOUT_REASON, reason);
    } catch {}
  },

  /** Returns the pending logout reason (if any) and clears it immediately so
   *  the banner is shown only once. */
  async consumeLogoutReason(): Promise<string | null> {
    try {
      const val = await AsyncStorage.getItem(KEYS.LOGOUT_REASON);
      if (val) await AsyncStorage.removeItem(KEYS.LOGOUT_REASON);
      return val;
    } catch {
      return null;
    }
  },

  // ── Backfill timestamp (AsyncStorage) ─────────────────────────────────────

  /**
   * Returns the epoch-ms timestamp of the last successful stream-URL backfill,
   * or 0 if none has been recorded yet.
   */
  async getLastBackfillTs(): Promise<number> {
    try {
      const val = await AsyncStorage.getItem(KEYS.BACKFILL_TS);
      return val ? parseInt(val, 10) : 0;
    } catch {
      return 0;
    }
  },

  /** Persists the current time as the last backfill timestamp. */
  async setLastBackfillTs(ts: number): Promise<void> {
    await AsyncStorage.setItem(KEYS.BACKFILL_TS, String(ts));
  },

  // ── Recent searches ────────────────────────────────────────────────────────
  async getRecentSearches(): Promise<string[]> {
    try {
      const raw = await AsyncStorage.getItem(KEYS.RECENT_SEARCHES);
      return raw ? (JSON.parse(raw) as string[]) : [];
    } catch { return []; }
  },

  /** Prepends `query` to the recent-search list, deduplicating and capping at 10. */
  async addRecentSearch(query: string): Promise<void> {
    const q = query.trim();
    if (!q) return;
    try {
      const existing = await this.getRecentSearches();
      const updated = [q, ...existing.filter((s) => s !== q)].slice(0, 10);
      await AsyncStorage.setItem(KEYS.RECENT_SEARCHES, JSON.stringify(updated));
    } catch {}
  },

  async clearRecentSearches(): Promise<void> {
    await AsyncStorage.removeItem(KEYS.RECENT_SEARCHES);
  },

  async removeRecentSearch(query: string): Promise<void> {
    try {
      const existing = await this.getRecentSearches();
      await AsyncStorage.setItem(KEYS.RECENT_SEARCHES, JSON.stringify(existing.filter((s) => s !== query)));
    } catch {}
  },

  // ── UI preferences (AsyncStorage — NOT cleared on logout) ─────────────────
  // Device-scoped preferences (sort order, last category, playback speed).
  // These intentionally survive logout so the app feels familiar on re-login.
  // They are NOT included in clearCredentials and use the @pref_* key prefix.

  async getPrefMovieSort(): Promise<'newest' | 'name' | 'rating' | null> {
    try {
      const v = await AsyncStorage.getItem(DEVICE_PREF_KEYS.PREF_MOVIE_SORT);
      return v === 'name' || v === 'rating' || v === 'newest' ? v : null;
    } catch { return null; }
  },

  async setPrefMovieSort(sort: 'newest' | 'name' | 'rating'): Promise<void> {
    await AsyncStorage.setItem(DEVICE_PREF_KEYS.PREF_MOVIE_SORT, sort);
  },

  async getPrefSeriesSort(): Promise<'newest' | 'name' | 'rating' | null> {
    try {
      const v = await AsyncStorage.getItem(DEVICE_PREF_KEYS.PREF_SERIES_SORT);
      return v === 'name' || v === 'rating' || v === 'newest' ? v : null;
    } catch { return null; }
  },

  async setPrefSeriesSort(sort: 'newest' | 'name' | 'rating'): Promise<void> {
    await AsyncStorage.setItem(DEVICE_PREF_KEYS.PREF_SERIES_SORT, sort);
  },

  async getPrefLiveCat(): Promise<string | null> {
    try { return await AsyncStorage.getItem(DEVICE_PREF_KEYS.PREF_LIVE_CAT); }
    catch { return null; }
  },

  async setPrefLiveCat(cat: string): Promise<void> {
    await AsyncStorage.setItem(DEVICE_PREF_KEYS.PREF_LIVE_CAT, cat);
  },

  async getPrefPlaybackSpeed(): Promise<number | null> {
    try {
      const v = await AsyncStorage.getItem(DEVICE_PREF_KEYS.PREF_PLAYBACK_SPEED);
      const n = v ? parseFloat(v) : NaN;
      return !isNaN(n) && n > 0 ? n : null;
    } catch { return null; }
  },

  async setPrefPlaybackSpeed(speed: number): Promise<void> {
    await AsyncStorage.setItem(DEVICE_PREF_KEYS.PREF_PLAYBACK_SPEED, String(speed));
  },
};
