# StreamVault Live TV / VLC diagnostic source

This archive is a read-only diagnostic copy. It was assembled from the current project without modifying the app.

It contains:
- Live TV, mini-player, fullscreen, handoff, navigation, geometry, and channel/zap source.
- Direct playback services and relevant regression tests.
- Android project manifests, Gradle configuration, lifecycle classes, and Expo config plugins.
- The complete checked-in react-native-vlc-media-player JS/config/native bridge source needed to inspect the installed integration.
- The custom pnpm patch applied to that dependency.
- A redacted EAS profile copy. The original project config was not copied because it contains an API-key value.

The package does not contain libVLC C/C++ source because the app consumes libVLC as a prebuilt Maven Android artifact. The dependency Gradle file identifies that artifact and version.

The APKs, signing files, node_modules, generated Android output, caches, credentials, environment files, and secrets were intentionally excluded.
