# StreamVault VLC mini/fullscreen fix package

This package is based on the source snapshot used for Android APK 268, with a targeted source repair for the two issues observed on a physical Android phone.

## Required behavior
1. The first selected Live TV channel must render video in the mini-player immediately. Opening fullscreen must not be required to initialise the video surface.
2. Mini -> fullscreen and fullscreen -> mini must retain one continuous VLC/libVLC playback session. No stop/restart/reconnect or second player.
3. Fullscreen must use the actual Android window dimensions and fill the fullscreen presentation frame. It must not inherit the mini-player 16:9 bounds.
4. The native VLC resize mode remains `fill` during the handoff.

## Targeted changes in this package
- Added repeated `measureInWindow` fallback measurement after first mini-player channel selection so the persistent VLC presentation host gets valid mini bounds even if the first React Native layout event arrives before the native hierarchy is settled.
- Fullscreen presentation frame is explicitly sized from `useWindowDimensions()` rather than a stale preview/root measurement.
- Fullscreen tab scene is explicitly positioned to the full available window when the native surface is fullscreen, preventing the old sidebar/preview geometry from constraining the VLC frame.
- Included the native Android activity/application source that was missing from the APK-268 source ZIP and the existing react-native-vlc-media-player patch.

Do not replace unrelated application code. Preserve the one-player/no-restart handoff behavior.
