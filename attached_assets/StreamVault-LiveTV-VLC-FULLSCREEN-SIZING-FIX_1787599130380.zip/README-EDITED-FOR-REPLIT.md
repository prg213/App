# StreamVault VLC diagnostic patch prepared by ChatGPT

This archive contains targeted source edits intended for Replit to review/apply, not a blindly generated APK.

Changes:
- Added native `resizeMode` handling to the Android VLC view using libVLC `SURFACE_BEST_FIT`, `SURFACE_FIT_SCREEN`, and `SURFACE_FILL`.
- Explicitly call libVLC Vout `updateVideoSurfaces()` after layout/size changes so the existing decoder/output is resized in place.
- Stop passing the mini-player's measured aspect ratio into fullscreen, which previously allowed mini geometry to persist into fullscreen.
- Keep the existing single persistent VLC player architecture and continuous audio; no source replacement or player recreation was added to the transition.

Important: this is source-level work only. A real Android build/test is still required before considering the fix complete.


## Follow-up fullscreen sizing fix

The latest targeted edit removes the fullscreen container's inherited 16:9 constraint and makes it occupy the complete fullscreen viewport. The persistent Android VLC surface/session is unchanged. The fullscreen presentation now requests `cover` while the mini-player remains `contain`, so the video does not snap back to a narrower 16:9 rectangle after the final layout pass.
